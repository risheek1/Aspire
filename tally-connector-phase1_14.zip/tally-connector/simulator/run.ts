/**
 * Standalone mock Connector Gateway — a stand-in for the real cloud API so the
 * connector can be tested end-to-end before the backend exists.
 *
 *   npm run build && node dist/simulator/run.js          # listens on :8080
 *   PORT=9000-something PENDING_DEMO=1 node dist/simulator/run.js
 *
 * Then point the connector at it:
 *   API_BASE=http://127.0.0.1:8080  DEVICE_TOKEN=anything
 * (the mock accepts any token — auth is a real-gateway concern)
 *
 * PENDING_DEMO=1 seeds one demo Receipt command so you can watch down-sync
 * write a voucher INTO Tally. Edit the ledger names below to ones that exist
 * in your Tally company, or the import will (correctly) be acked 'failed'.
 */
import { CloudSimulator } from './cloudSim';

const port = parseInt(process.env.PORT ?? '8080', 10);

async function main() {
  const sim = new CloudSimulator();
  const actual = await sim.listen(port);
  console.log(`mock gateway listening on http://127.0.0.1:${actual}`);
  console.log(`connector env:  API_BASE=http://127.0.0.1:${actual}  DEVICE_TOKEN=dev`);

  if (process.env.PENDING_DEMO === '1') {
    sim.pending.push({
      id: 'demo-' + Date.now(),
      company: '',
      date: new Date().toISOString().slice(0, 10).replace(/-/g, ''),
      voucherType: 'Receipt',
      number: 'DEMO-1',
      narration: 'demo payment from mock gateway',
      entries: [
        { ledger: 'Cash', amount: 100 }, // <-- change to real ledger names
        { ledger: 'Sales', amount: -100 },
      ],
    });
    console.log('seeded 1 demo pending command (PENDING_DEMO=1)');
  }

  let lastReceived = 0;
  let lastAcks = 0;
  setInterval(() => {
    const rec = sim.received.size;
    const acks = sim.acks.length;
    if (rec !== lastReceived || acks !== lastAcks) {
      console.log(
        `[${new Date().toISOString().slice(11, 19)}] unique records ingested: ${rec} ` +
          `(batch calls: ${sim.pushCalls}) | pending: ${sim.pending.length} | acks: ${JSON.stringify(sim.acks.slice(-3))}`,
      );
      lastReceived = rec;
      lastAcks = acks;
    }
  }, 2000);
}

main();

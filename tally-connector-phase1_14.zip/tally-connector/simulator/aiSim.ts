/**
 * Simulates the accounting-integrations backend for CI: the Express auth
 * endpoints (PIN flow) + the /v1/tally/* surface with the §1A wire shapes.
 * Fetches are DESTRUCTIVE like production: once served, never re-delivered.
 */
import http from 'node:http';

export class AISimulator {
  private server: http.Server;
  readonly PIN = '246810';
  tokenExpiresIn = 605000; // ~7 days, like production
  failAcks = false; // fault switch: ack endpoints return 500

  // seedable pending data (served once each)
  vendors: any[] = [];
  items: any[] = [];
  bills: any[] = []; // wrappers: { sync_entry_id, bill: {...} }
  advances: any[] = [];

  // observability for assertions
  masters: Record<string, any[]> = {};
  acks: { path: string; body: any }[] = [];
  integrations: any[] = [];
  authorizeCalls = 0;
  fetchCalls: string[] = [];

  constructor() {
    this.server = http.createServer((req, res) => this.handle(req, res));
  }

  listen(port = 0): Promise<number> {
    return new Promise((r) => this.server.listen(port, '127.0.0.1', () => r((this.server.address() as any).port)));
  }

  close() {
    this.server.close();
  }

  private handle(req: http.IncomingMessage, res: http.ServerResponse) {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      const url = new URL(req.url ?? '/', 'http://x');
      const body = raw ? JSON.parse(raw) : {};
      res.setHeader('Content-Type', 'application/json');
      const send = (code: number, data: unknown) => {
        res.writeHead(code);
        res.end(JSON.stringify(data));
      };

      // ---- auth (Express) ----
      if (url.pathname === '/tally/v1/auth/authorize') {
        this.authorizeCalls++;
        if (body.product !== 'banking' || body.feature !== 'accounting_integration') {
          return send(400, { error: 'missing product/feature' });
        }
        return send(200, { success: true });
      }
      if (url.pathname === '/tally/v1/auth/token') {
        if (body.pin !== this.PIN) return send(401, { error: 'invalid pin' });
        if (body.grant_type !== 'tally_client_credentials') return send(400, { error: 'bad grant' });
        return send(200, {
          access_token: 'jwt-sim-token',
          token_type: 'Bearer',
          expires_in: this.tokenExpiresIn,
          public_token: 'pub-sim',
        });
      }

      // ---- everything below requires the bearer ----
      if (req.headers.authorization !== 'Bearer jwt-sim-token') {
        return send(401, { success: false });
      }

      if (url.pathname === '/v1/tally/integrate') {
        const id = `int_${this.integrations.length + 1}`;
        this.integrations.push({ id, ...body });
        return send(200, { integration_id: id });
      }
      if (url.pathname === '/v1/tally/plugin/version') {
        return send(200, { success: true });
      }

      // masters
      const master = url.pathname.match(/^\/v1\/tally\/(?:send|sync)\/([a-z-]+)$/);
      if (master) {
        (this.masters[master[1]] ??= []).push(body);
        return send(200, { success: true });
      }

      // fetch (destructive; integration_id required as query param)
      const fetch_ = url.pathname.match(/^\/v1\/tally\/fetch\/([a-z-]+)$/);
      if (fetch_) {
        if (!url.searchParams.get('integration_id')) return send(400, { success: false });
        this.fetchCalls.push(fetch_[1]);
        const drain = <T>(arr: T[]): T[] => arr.splice(0, arr.length);
        switch (fetch_[1]) {
          case 'vendors':
            return send(200, { success: true, vendors: drain(this.vendors), has_more: false });
          case 'items':
            return send(200, { success: true, items: drain(this.items), has_more: false });
          case 'bills':
            return send(200, { success: true, invoices: drain(this.bills) });
          case 'vendor-advances':
            return send(200, { success: true, advances: drain(this.advances) });
        }
      }

      // acks
      if (url.pathname.startsWith('/v1/tally/ack/') || /^\/v1\/transactions\/.+\/ack$/.test(url.pathname)) {
        if (this.failAcks) return send(500, { success: false });
        this.acks.push({ path: url.pathname, body });
        return send(200, { success: true });
      }

      send(404, { success: false });
    });
  }
}

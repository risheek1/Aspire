import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TallySimulator } from '../simulator/tallySim';
import { LiteGateway } from '../src/gateway-lite';
import { Store } from '../src/store';
import { TallyAdapter } from '../src/tally/adapter';
import { CloudClient } from '../src/cloud/client';
import { SyncEngine } from '../src/sync/engine';
import { Logger } from '../src/logger';

let tally: TallySimulator;
let gw: LiteGateway;
let tallyPort: number;
let gwPort: number;
let dir: string;

beforeEach(async () => {
  tally = new TallySimulator();
  gw = new LiteGateway(); // no persistence in tests
  tallyPort = await tally.listen();
  gwPort = await gw.listen();
  dir = mkdtempSync(join(tmpdir(), 'gwlite-'));
});

afterEach(() => {
  tally.close();
  gw.close();
  rmSync(dir, { recursive: true, force: true });
});

function makeEngine() {
  const store = new Store(join(dir, 'e.db'));
  const engine = new SyncEngine(
    new TallyAdapter({ url: `http://127.0.0.1:${tallyPort}`, timeoutMs: 400 }),
    new CloudClient(`http://127.0.0.1:${gwPort}`, 'dev', fetch, 400),
    store,
    new Logger('error', 100, () => {}),
    { companies: [''], entities: ['vouchers'], pageSize: 100, maxPagesPerTick: 5 },
  );
  return { store, engine };
}

describe('production engine against gateway-lite', () => {
  it('full loop: up-sync ingests idempotently, command round-trips into Tally', async () => {
    tally.addVoucher();
    tally.addVoucher();
    const cmdId = gw.seedCommand({
      date: '20260729',
      voucherType: 'Receipt',
      number: 'R-1',
      narration: 'from lite gateway',
      entries: [
        { ledger: 'Cash', amount: -500 },
        { ledger: 'Sales', amount: 500 },
      ],
    });

    const { store, engine } = makeEngine();
    await engine.tick();

    expect(gw.entryCount()).toBe(2); // both vouchers ingested
    expect(tally.importedExternalIds).toContain(cmdId); // command written into Tally

    // Re-tick: idempotent (cursor holds; command acked away)
    await engine.tick();
    expect(gw.entryCount()).toBeGreaterThanOrEqual(2);
    expect(tally.importedExternalIds.filter((x) => x === cmdId)).toHaveLength(1);
    store.close();
  });

  it('lightweight extras: /entries browse and /commands validation', async () => {
    tally.addVoucher({ VOUCHERTYPENAME: 'Sales', PARTYLEDGERNAME: 'Acme Traders' });
    const { store, engine } = makeEngine();
    await engine.tick();

    const browse = await (await fetch(`http://127.0.0.1:${gwPort}/entries?party=Acme`)).json();
    expect(browse.count).toBe(1);

    const bad = await fetch(`http://127.0.0.1:${gwPort}/commands`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ date: '20260729', voucherType: 'Receipt', entries: [{ ledger: 'Cash', amount: 100 }] }),
    });
    expect(bad.status).toBe(400); // unbalanced entries rejected

    const good = await fetch(`http://127.0.0.1:${gwPort}/commands`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        date: '20260729',
        voucherType: 'Receipt',
        entries: [
          { ledger: 'Cash', amount: -100 },
          { ledger: 'Sales', amount: 100 },
        ],
      }),
    });
    expect(good.status).toBe(200);
    const { id } = await good.json();

    await engine.tick(); // connector picks it up and imports
    expect(tally.importedExternalIds).toContain(id);

    const status = await (await fetch(`http://127.0.0.1:${gwPort}/status`)).json();
    expect(status.pending).toBe(0);
    expect(status.acks.some((a: any) => a.id === id && a.status === 'imported')).toBe(true);
    store.close();
  });
});

describe('ledger commands (create / update / categorize)', () => {
  const post = (body: any) =>
    fetch(`http://127.0.0.1:${gwPort}/commands`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

  it('creates a ledger with categorization, idempotent on redelivery and on natural key', async () => {
    const r = await post({ kind: 'ledger', action: 'create', name: 'Wayne Traders', parent: 'Sundry Debtors', gstin: '29ABCDE1234F1Z5' });
    expect(r.status).toBe(200);
    const { id } = await r.json();

    const { store, engine } = makeEngine();
    await engine.tick();
    const led = tally.getLedger('Wayne Traders');
    expect(led).toBeDefined();
    expect(led!.PARENT).toBe('Sundry Debtors');
    expect(led!.PARTYGSTIN).toBe('29ABCDE1234F1Z5');

    // second create for the same name (different command id) -> duplicate, not a second ledger
    await post({ kind: 'ledger', action: 'create', name: 'Wayne Traders', parent: 'Sundry Debtors' });
    await engine.tick();
    const status = await (await fetch(`http://127.0.0.1:${gwPort}/status`)).json();
    expect(status.acks.some((a: any) => a.status === 'duplicate')).toBe(true);
    expect(status.acks.some((a: any) => a.id === id && a.status === 'imported')).toBe(true);
    store.close();
  });

  it('updates properties and recategorizes an existing ledger', async () => {
    tally.addLedger({ GUID: 'lg-w', NAME: 'Wayne Traders', PARENT: 'Sundry Debtors' });
    await post({ kind: 'ledger', action: 'update', name: 'Wayne Traders', parent: 'Sundry Creditors', email: 'ap@wayne.example' });

    const { store, engine } = makeEngine();
    await engine.tick();
    const led = tally.getLedger('Wayne Traders');
    expect(led!.PARENT).toBe('Sundry Creditors'); // recategorized
    expect(led!.EMAIL).toBe('ap@wayne.example');
    store.close();
  });

  it('update of a nonexistent ledger is acked failed with LEDGER_NOT_FOUND', async () => {
    await post({ kind: 'ledger', action: 'update', name: 'Ghost Ledger', parent: 'Sundry Debtors' });
    const { store, engine } = makeEngine();
    await engine.tick();
    const status = await (await fetch(`http://127.0.0.1:${gwPort}/status`)).json();
    const ack = status.acks.find((a: any) => a.status === 'failed');
    expect(ack?.detail?.code).toBe('LEDGER_NOT_FOUND');
    store.close();
  });

  it('validation: create without parent is rejected at the gateway', async () => {
    const r = await post({ kind: 'ledger', action: 'create', name: 'X' });
    expect(r.status).toBe(400);
  });
});

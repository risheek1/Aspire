import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TallySimulator } from '../simulator/tallySim';
import { AISimulator } from '../simulator/aiSim';
import { Store } from '../src/store';
import { TallyAdapter } from '../src/tally/adapter';
import { SyncEngine } from '../src/sync/engine';
import { Logger } from '../src/logger';
import { PassportAuth, AuthExpiredError, TokenRecord } from '../src/cloud/passportAuth';
import { AccountingIntegrationsClient } from '../src/cloud/aiClient';
import { toLedgerGroupsTree } from '../src/cloud/transformers';

let tally: TallySimulator;
let ai: AISimulator;
let tallyPort: number;
let aiPort: number;
let dir: string;

class MemTokenStorage {
  t: TokenRecord | null = null;
  get() { return this.t; }
  set(t: TokenRecord) { this.t = t; }
}

function makeAuthed() {
  const storage = new MemTokenStorage();
  const auth = new PassportAuth(
    { authBase: `http://127.0.0.1:${aiPort}`, clientId: 'cid', clientSecret: 'sec' },
    storage,
  );
  return { auth, storage };
}

function makeEngine(auth: PassportAuth, db = 'e.db') {
  const store = new Store(join(dir, db));
  const client = new AccountingIntegrationsClient(
    { apiBase: `http://127.0.0.1:${aiPort}`, integrationId: 'int_1', timeoutMs: 500 },
    auth,
  );
  const engine = new SyncEngine(
    new TallyAdapter({ url: `http://127.0.0.1:${tallyPort}`, timeoutMs: 400 }),
    client,
    store,
    new Logger('error', 100, () => {}),
    { companies: [''], entities: ['ledgers'], pageSize: 100, maxPagesPerTick: 5 },
  );
  return { store, engine, client };
}

beforeEach(async () => {
  tally = new TallySimulator();
  ai = new AISimulator();
  tallyPort = await tally.listen();
  aiPort = await ai.listen();
  dir = mkdtempSync(join(tmpdir(), 'ai-'));
});

afterEach(() => {
  tally.close();
  ai.close();
  rmSync(dir, { recursive: true, force: true });
});

describe('Passport auth (PIN flow)', () => {
  it('authorize -> PIN exchange -> bearer; expiry raises AUTH_EXPIRED', async () => {
    const { auth, storage } = makeAuthed();
    await auth.authorize('merchant@example.com', 'merch_1');
    expect(ai.authorizeCalls).toBe(1);

    await expect(auth.exchangePin('merchant@example.com', 'merch_1', '000000')).rejects.toThrow(/401/);
    const rec = await auth.exchangePin('merchant@example.com', 'merch_1', ai.PIN);
    expect(rec.accessToken).toBe('jwt-sim-token');
    expect(auth.bearer()).toBe('Bearer jwt-sim-token');
    expect(auth.expiringSoon(1)).toBe(false);
    expect(auth.expiringSoon(8)).toBe(true); // ~7-day token: day-6 warning window works

    storage.t!.expiresAt = Date.now() - 1;
    expect(() => auth.bearer()).toThrow(AuthExpiredError);
  });

  it('integrate binds to the Tally company GUID and returns integration_id', async () => {
    const { auth } = makeAuthed();
    await auth.exchangePin('m@x.com', 'merch_1', ai.PIN);
    const { client } = makeEngine(auth);
    const id = await client.integrate('m@x.com', 'simco-guid-0001');
    expect(id).toBe('int_1');
    expect(ai.integrations[0]).toMatchObject({ user_email: 'm@x.com', company_id: 'simco-guid-0001' });
  });
});

describe('masters up-sync onto the /v1/tally surface', () => {
  it('ledgers flow to send/chart-of-accounts with Tally GUIDs as ids', async () => {
    tally.addLedger({ GUID: 'co-guid-000000a1', NAME: 'Wayne Traders', PARENT: 'Sundry Creditors', PARTYGSTIN: '29X' });
    const { auth } = makeAuthed();
    await auth.exchangePin('m@x.com', 'merch_1', ai.PIN);
    const { store, engine } = makeEngine(auth);

    await engine.tick();
    const sent = ai.masters['chart-of-accounts']?.[0];
    expect(sent.integration_id).toBe('int_1');
    expect(sent.chart_of_accounts[0]).toMatchObject({
      ledger_id: 'co-guid-000000a1',
      ledger_name: 'Wayne Traders',
      group_name: 'Sundry Creditors',
      gstin: '29X',
    });
    store.close();
  });

  it('flat groups assemble into the nested ledger_groups tree', () => {
    const rec = (guid: string, name: string, parent: string) =>
      ({ guid, masterId: guid, alterId: 1, raw: { NAME: name, PARENT: parent } }) as any;
    const tree = toLedgerGroupsTree([
      rec('g-1', 'Current Liabilities', ''),
      rec('g-2', 'Duties & Taxes', 'Current Liabilities'),
      rec('g-3', 'GST Payable', 'Duties & Taxes'),
    ]);
    expect(tree).toHaveLength(1);
    expect(tree[0].group_name).toBe('Current Liabilities');
    expect(tree[0].sub_groups[0].group_name).toBe('Duties & Taxes');
    expect(tree[0].sub_groups[0].group_parent_id).toBe('g-1');
    expect(tree[0].sub_groups[0].sub_groups[0].group_name).toBe('GST Payable');
  });
});

describe('down-sync loop against destructive fetches', () => {
  const vendor = { id: 'cont_9', name: 'Stark Supplies', external_group_name: 'Sundry Creditors', gstin: '27S' };
  const advance = {
    id: 'va_5', amount: 50000, payable_amount: 48000, created_date: '2026-07-30',
    contact: { rx_id: 'cont_9', external_name: 'Stark Supplies' },
    source_account: { external_name: 'HDFC Bank' },
    tds_taxes: [{ tds_amount: 2000, tds_category: { external_name: 'TDS Payable' } }],
  };

  it('vendor -> ledger in Tally -> ack/vendors with §1A shape', async () => {
    ai.vendors.push(vendor);
    const { auth } = makeAuthed();
    await auth.exchangePin('m@x.com', 'merch_1', ai.PIN);
    const { store, engine } = makeEngine(auth);

    await engine.tick();
    expect(tally.getLedger('Stark Supplies')).toBeDefined();
    const ack = ai.acks.find((a) => a.path === '/v1/tally/ack/vendors');
    expect(ack?.body.vendors[0]).toMatchObject({ rx_id: 'cont_9', external_name: 'Stark Supplies', success: true });
    store.close();
  });

  it('advance -> balanced Payment voucher -> ack/vendor-advances with uppercase action + contact', async () => {
    tally.addLedger({ GUID: 'lg-s', NAME: 'Stark Supplies' });
    ai.advances.push(advance);
    const { auth } = makeAuthed();
    await auth.exchangePin('m@x.com', 'merch_1', ai.PIN);
    const { store, engine } = makeEngine(auth);

    await engine.tick();
    expect(tally.importedExternalIds).toContain('va_5');
    const ack = ai.acks.find((a) => a.path === '/v1/tally/ack/vendor-advances');
    expect(ack?.body.advances[0]).toMatchObject({ rx_id: 'va_5', success: true, action: 'CREATE' });
    expect(ack?.body.advances[0].contact[0].external_name).toBe('Stark Supplies');
    store.close();
  });

  it('CHAOS: fetched-but-unacked commands survive restart via the inbox (backend never re-delivers)', async () => {
    ai.vendors.push(vendor);
    const { auth } = makeAuthed();
    await auth.exchangePin('m@x.com', 'merch_1', ai.PIN);

    // Tick 1: fetch drains the backend queue, ledger is created in Tally, but
    // every ack fails (backend 500s) — the "crash before ack" window, held open.
    ai.failAcks = true;
    const a = makeEngine(auth, 'crash.db');
    await a.engine.tick();
    expect(ai.vendors).toHaveLength(0); // destructively fetched — gone server-side
    expect(a.store.inboxAll()).toHaveLength(1); // but safely banked locally
    expect(tally.getLedger('Stark Supplies')).toBeDefined();
    a.store.close();

    // "Restart": new engine, same DB, acks healthy. The command replays from
    // the inbox; dedupe (already imported) resolves it, the ack lands, inbox clears.
    ai.failAcks = false;
    const b = makeEngine(auth, 'crash.db');
    await b.engine.tick();
    expect(b.store.inboxAll()).toHaveLength(0);
    const ack = ai.acks.find((x) => x.path === '/v1/tally/ack/vendors');
    expect(ack?.body.vendors[0]).toMatchObject({ rx_id: 'cont_9', success: true });
    // and exactly ONE ledger despite the replay
    expect(tally['ledgers'].filter((l: any) => l.NAME === 'Stark Supplies')).toHaveLength(1);
    b.store.close();
  });

  it('Tally rejection acks failed with the reason and clears the inbox', async () => {
    ai.advances.push({ ...advance, id: 'va_bad' });
    // contact ledger deliberately missing -> import_error via sim fault
    tally.fault = 'import_error';
    const { auth } = makeAuthed();
    await auth.exchangePin('m@x.com', 'merch_1', ai.PIN);
    const { store, engine } = makeEngine(auth);

    await engine.tick();
    const ack = ai.acks.find((a) => a.path === '/v1/tally/ack/vendor-advances');
    expect(ack?.body.advances[0].success).toBe(false);
    expect(ack?.body.advances[0].failure_reason).toBeTruthy();
    expect(store.inboxAll()).toHaveLength(0); // terminal outcome, cleared
    store.close();
  });

  it('AUTH_EXPIRED surfaces as a non-retryable error, sync does not silently stall', async () => {
    const { auth, storage } = makeAuthed();
    await auth.exchangePin('m@x.com', 'merch_1', ai.PIN);
    const { store, engine } = makeEngine(auth);
    storage.t!.expiresAt = Date.now() - 1;

    tally.addLedger({ GUID: 'l-x', NAME: 'X' });
    const report = await engine.tick();
    expect(report.errors['CLOUD_AUTH']).toBeGreaterThan(0);
    store.close();
  });
});

describe('ConnectorService activation flow (first-run)', () => {
  it('needs_registration -> PIN -> integrate(company GUID) -> activated -> syncing', async () => {
    const { ConnectorService } = await import('../src/service');
    const { Logger } = await import('../src/logger');
    tally.addLedger({ GUID: 'co-g-01', NAME: 'Alpha Traders', PARENT: 'Sundry Debtors' });

    const svc = new ConnectorService(
      {
        backend: 'ai',
        authBase: `http://127.0.0.1:${aiPort}`,
        aiApiBase: `http://127.0.0.1:${aiPort}`,
        clientId: 'cid',
        clientSecret: 'sec',
        tallyUrl: `http://127.0.0.1:${tallyPort}`,
        companies: [],
        apiBase: '',
        deviceToken: '',
        pollIntervalMs: 60000,
        pageSize: 100,
        dbPath: join(dir, 'svc.db'),
        hintPort: 0,
        outboxMaxBatches: 100,
        logLevel: 'error',
      },
      new Logger('error', 100, () => {}),
    );

    expect(svc.getActivationState()).toBe('needs_registration');
    svc.start(); // must NOT sync yet
    expect(svc.getStatus().activationState).toBe('needs_registration');

    await svc.startActivation('m@x.com', 'merch_1');
    expect(svc.getActivationState()).toBe('needs_pin');
    expect(ai.authorizeCalls).toBe(1);

    await expect(svc.completeActivation('999999')).rejects.toThrow(); // wrong PIN
    await svc.completeActivation(ai.PIN);
    expect(svc.getActivationState()).toBe('activated');
    // integrate was bound to the open Tally company GUID
    expect(ai.integrations[0]).toMatchObject({ user_email: 'm@x.com', company_id: 'simco-guid-0001' });

    // first tick fires post-activation and masters flow
    await new Promise((r) => setTimeout(r, 300));
    expect(ai.masters['chart-of-accounts']?.length).toBeGreaterThan(0);
    await svc.stop();
  });

  it('restart with stored integration+token resumes as activated (no re-PIN)', async () => {
    const { ConnectorService } = await import('../src/service');
    const { Logger } = await import('../src/logger');
    const cfg = {
      backend: 'ai' as const,
      authBase: `http://127.0.0.1:${aiPort}`,
      aiApiBase: `http://127.0.0.1:${aiPort}`,
      clientId: 'cid', clientSecret: 'sec',
      tallyUrl: `http://127.0.0.1:${tallyPort}`,
      companies: [], apiBase: '', deviceToken: '',
      pollIntervalMs: 60000, pageSize: 100,
      dbPath: join(dir, 'resume.db'), hintPort: 0, outboxMaxBatches: 100,
      logLevel: 'error' as const,
    };
    const a = new ConnectorService(cfg, new Logger('error', 100, () => {}));
    await a.startActivation('m@x.com', 'merch_1');
    await a.completeActivation(ai.PIN);
    await a.stop();

    const b = new ConnectorService(cfg, new Logger('error', 100, () => {}));
    expect(b.getActivationState()).toBe('activated');
    await b.stop();
  });
});

# How the Tally Connector Works — Workflow Documentation

This document explains every logical workflow inside the connector, in plain language but in full depth. It is written for two readers at once: someone new who wants to understand the system top-to-bottom, and someone debugging at 2 AM who wants to jump to the failure story that matches their symptom. Code references point at files in this repo. Where a design choice was forced by something that actually broke in the field, the incident is told inline — those lessons are the most valuable part.

---

## 1. The big picture

The connector is a small program on the same Windows PC as Tally. Its job is to be a reliable courier between two parties that cannot talk to each other:

- **Tally**: speaks XML over HTTP on `localhost:9000`, only while open with a company loaded, and has no memory of what it already told you.
- **The gateway API** (the production cloud service, or `gateway-lite` locally): lives across an unreliable network.

The courier's promise: **every change in Tally reaches the gateway exactly once, and every command from the gateway lands in Tally exactly once — regardless of crashes, restarts, offline periods, company switches, or Tally-version quirks.** Everything below serves that promise.

Three files carry it: `src/sync/engine.ts` (decisions), `src/store.ts` (memory), `src/tally/xml.ts` (translation). Everything else is plumbing around them.

---

## 2. What the connector remembers (the local database)

All durable state lives in one SQLite file, `connector.db` (dev mode: the working directory; installed app: under `%APPDATA%` — they are different databases, a recurring source of confusion during testing). Built on Node's built-in `node:sqlite`: zero native dependencies, nothing to compile on any machine.

**`cursors`** — one row per (**company GUID**, entity). The highest Tally `AlterID` safely handed off. This is the bookmark; all incremental sync reduces to "what's my cursor?"

> **Field lesson — why the key is the GUID.** Cursors were originally keyed by the config string, where `''` meant "whichever company is open." AlterID counters are *per-company*, so when the operator switched Tally from a large demo company to a small one, the shared cursor sat far above the small company's entire history — and sync went perfectly, silently idle: `tallyUp: true`, zero records, zero errors, forever. The cursor key is now the company's GUID, resolved live from Tally each tick, so every company keeps its own bookmark and switching is harmless. The doctor also has a cursor-sanity check (stored cursor above the open company's max AlterID → loud failure naming the cause).

**`outbox`** — batches read from Tally but not yet delivered to the gateway: payload, attempt counter, next-retry time. Why offline loses nothing.

**`imported_ids`** — every external command ID ever written into Tally. First line of defence against double imports.

Why SQLite over a JSON file: transactions. Several workflows need two changes to happen *together or not at all* ("enqueue batch AND advance cursor"). `BEGIN IMMEDIATE … COMMIT` gives that; a JSON file can be half-written when the power dies.

---

## 3. The heartbeat of everything: the tick

All work happens in a **tick** — one bounded unit of syncing, every `POLL_INTERVAL_MS` (default 20 s), strictly serialized (never overlapped; `src/service.ts` owns the schedule, `engine.tick()` does the work). Four phases, in order:

```
1. PING       is Tally answering?
2. FLUSH      retry anything stuck in the outbox
3. UP-SYNC    Tally → gateway (new/changed records)
4. DOWN-SYNC  gateway → Tally (commands to import)
```

Two ordering subtleties: **flush runs even when Tally is down** (Tally closed says nothing about the internet — yesterday's queued batches still deliver), and **ping failure is a normal state, not an error** (merchants close Tally every evening; the tick idles at debug level and reports `tally_down` in the heartbeat). A tick never throws outward; every phase counts its errors into a `TickReport` feeding the status window and heartbeat.

---

## 4. Up-sync in depth: Tally → gateway

### 4.1 Knowing what changed: AlterID

Tally maintains one per-company counter, **AlterID**, ticking up on every create or modify; every voucher and master carries the AlterID of its own last change. "What changed since I looked?" becomes one filter: *everything with AlterID greater than my cursor.* The connector sends that filter as an **inline TDL collection** — the query definition rides inside the HTTP request (`fetchChangedEnvelope`), so nothing is ever installed inside the merchant's Tally.

Free consequences: **edits are captured** (an edited record gets a fresh AlterID and reappears as a new version of the same GUID — including ledger renames and property changes), and **first sync is not special** (cursor 0 means "everything," so backfill is just the normal loop). Not free: **deletions** — a deleted record vanishes without a tombstone; catching those needs a periodic GUID reconciliation sweep (planned Phase 2 job).

### 4.2 Reading pages, and surviving Tally's dialects

Per company, per entity (vouchers, ledgers, stock items), within a tick: read cursor → ask Tally for changes above it (ascending, first `PAGE_SIZE` of 500) → hand off → advance cursor → repeat while Tally has more, up to `maxPagesPerTick` (20) so a giant backfill can't run a tick forever.

Real Tally responses are messier than any spec, and the translation layer absorbs three dialect problems, each discovered against a live installation:

- **Attributed fields.** Tally may return `<ALTERID TYPE="Number"> 1,204</ALTERID>` — which parses to an *object* with spaces and comma grouping. Naive coercion produced `NaN`, and `node:sqlite` binds NaN as NULL: the original production crash (`NOT NULL constraint failed: cursors.alter_id`). `toText`/`toInt` now coerce every known shape, and `normalizeRaw` flattens whole records to clean scalars before upload — including the empty form `{"@_TYPE":"String"}` (a blank NARRATION) that carries no text at all.
- **Fail loud, never wrong.** If an AlterID *still* won't parse, the adapter refuses the entire page with the raw record in the error, rather than guessing. A wrong cursor silently skips data forever; a refused page just retries and screams.
- **Error documents are not empty results.** Tally reports request problems as a **LINEERROR document** — which contains no records and is otherwise indistinguishable from "no changes." Treating it as empty once stalled an entity silently. LINEERROR is now a hard error; an envelope missing its COLLECTION node is treated as empty *but warned about* (some versions may legitimately omit it), so no response shape can ever read as silent-nothing.

### 4.3 Degrade gracefully: the FETCH fallback

The FETCH clause names exactly which fields Tally returns (like SQL columns — nothing else comes back; that is also why "detected but not carried" fields exist: we deliberately pull only what product needs, per the least-data commitment). Field *names* drift across Tally versions, and one bad optional field must never stall an entity. So if the full field list yields an unparseable or LINEERROR response, the adapter automatically retries the same page with a **minimal field set** (`NAME, PARENT, GUID, ALTERID, MASTERID` for ledgers) — sync proceeds, the extra fields come back blank, a warning is logged, and a `FETCH_DEGRADED` counter reaches telemetry so the field list gets fixed rather than living in fallback.

### 4.4 The handoff: direct push or outbox

**Gateway reachable** → POST the page to `/v1/connector/{entity}/batch`, advance the cursor, done. **Gateway unreachable** → in a *single SQLite transaction* (`Store.queueAndAdvance`), write the batch into the outbox AND advance the cursor. From that instant the outbox owns delivery: Tally is never re-asked for those records, and the batch retries until accepted.

Why advance the cursor on failure? The alternative — re-read the same records from Tally next tick — makes no forward progress while offline and grows unbounded. "Read from Tally" and "deliver to gateway" are decoupled; the outbox is the buffer. The transaction means there is no instant where a batch is dropped from Tally's view but not yet queued. **"Pending upload batches" in the status window is the row count of this table** — a rising number means Tally is being read fine and data is banked locally, not lost.

### 4.5 Flushing, backoff, poison

Every tick drains the outbox oldest-first (FIFO). Delivered → deleted. Network/5xx failure → attempts++, next retry by exponential backoff with jitter (2 s doubling to a 5-minute cap); flush stops at the first failure to preserve order. A **4xx rejection** means the payload itself is bad — *poison*: hot-retrying would block everything behind it, so the batch is parked for 24 h (never deleted; deleting merchant data is not an option), `OUTBOX_POISON` hits telemetry, and fresh data flows past it.

### 4.6 Why re-sends are harmless

At-least-once delivery means the gateway can see a record twice (crash after POST, before cursor write → page re-read). The gateway dedupes on **(company GUID, guid, alterId)**, first write wins — so replays store nothing. Exactly-once is, as always, at-least-once transport + an idempotent receiver.

---

## 5. Down-sync in depth: gateway → Tally

The gateway queues **commands**. Every tick the connector fetches `GET /v1/connector/pending` and processes each independently — one failure never blocks the rest. There are two command kinds with deliberately different dedupe designs.

### 5.1 Voucher commands (`kind` absent/`voucher`)

```
1. Imported this ID before?     (local imported_ids)         → ack 'duplicate'
2. Does Tally contain this ID?  (query the [ext:<id>] stamp) → record + ack 'duplicate'
3. Import the voucher.           Tally rejected → ack 'failed' + reason
4. Record the ID locally.        (BEFORE acking — order is the safety)
5. Ack 'imported'.
```

Two dedupe layers because each covers the other's blind spot: the local table is fast but lives on a deletable merchant PC; if it's lost, layer 2 asks Tally itself — every created voucher is stamped with the command's external ID (a UDF, mirrored as `[ext:<id>]` in the narration). Recording *before* acking means a crash between import and ack causes a redelivery that resolves as `duplicate`, never a second voucher — the one unforgivable outcome for accounting data.

The import itself is Tally's own engine: we POST an Import envelope describing the voucher (balanced `ALLLEDGERENTRIES.LIST` legs, debit = negative amount + `ISDEEMEDPOSITIVE Yes`), and Tally runs every validation an operator would face — ledgers must exist, period open, entries balanced. The result document (`CREATED/ALTERED/ERRORS`) is parsed strictly; we never guess whether an import worked.

### 5.2 Ledger commands (`kind: "ledger"`) — create, update, categorize

External systems can also manage ledger masters: `action: "create"` (requires `parent` — the Tally group, which IS the categorization), `action: "update"` (any provided property applied; `newName` renames). Properties: opening balance, GSTIN, email, phone, state, credit period, bill-wise.

Their dedupe is by **natural key — the ledger's name** — instead of a stamped ID: before any create, the connector asks Tally "does a ledger with exactly this name exist?"; yes → ack `duplicate`, and no second ledger is ever made, even when two systems both request "Wayne Traders". Updates are precondition-checked the opposite way (`failed: LEDGER_NOT_FOUND` if absent — never a silent create) and are naturally idempotent, since re-applying the same properties is harmless. This unlocks the real payment flow: an unknown payer becomes ledger-create (blindly safe) followed by the receipt voucher.

### 5.3 The echo

A voucher the connector writes gets its own AlterID, so up-sync carries it back to the gateway. Not a bug: the external-ID stamp travels with it, letting the gateway recognize "this originated from me" — a confirmation, not a new merchant entry.

---

## 6. Supporting workflows

**Company identity.** With no company configured, the engine resolves the open company's **GUID** live each tick (`listCompanies`) and uses it as both the cursor key and the batch's company scope. The service also caches name/GUID/books-from for the status window's company card, refreshed every ~15 ticks.

**Heartbeat and remote config.** After each tick: version, tally-up, outbox depth, error counters go up; the response may carry config overrides (poll interval, page size, log level) applied immediately — fleet tuning without shipping updates. Heartbeat failures are swallowed; telemetry never breaks syncing.

**The hint listener (push-assist).** Polling means up to 20 s of lag. The optional TDL add-on (`tdl/tally-connector-hint.tdl`) makes Tally POST to the connector (`127.0.0.1:9797`) the instant a voucher form is accepted. The handler does two things in a fixed order: respond `<STATUS>1</STATUS>` **immediately and unconditionally**, then pull the next tick forward (~250 ms, debounced). The order is a safety contract — Tally refuses to accept the form until it sees STATUS 1, so computing anything first would let our software freeze data entry. The hint carries no data and is only an accelerator; the cursor remains the sole source of truth, so a lost hint loses nothing.

**The Electron shell.** The engine runs in the main process (no window needed to sync). Tray: Status / Sync now / Quit. The status window is a dumb IPC panel: connection state, company card, last tick, pending upload batches, recent logs with full error context. Closing the window doesn't stop syncing. (Field note: dev mode and the installed app are separate builds with separate databases; on policy-managed machines, unsigned packaged exes may be blocked outright — dev mode runs Electron's signed binary and sails through, which is also the field evidence for why the EV code-signing certificate is a Phase 0 item.)

**The doctor** (`npm run doctor`). Tests each leg in isolation and names the broken one: SQLite writability → Tally ping (with the exact settings to check) → voucher query (printing the first raw record so field-shape drift is visible) → ledger query, full fields then minimal → **cursor sanity** (stored cursor above the company's max AlterID → "the DB was last synced against a different company") → gateway reachability/auth → hint port. It exists because three real incidents were each diagnosed in one run by a leg the logs couldn't see.

**gateway-lite** (`npm run gateway`). A single-file backend implementing the full production contract (idempotent batch ingest, pending/ack, heartbeat) plus lightweight extras: `GET /entries` (browse, filter by type/party) and `POST /commands` (queue voucher or ledger commands; voucher entries must balance to zero). JSON-file persistence. It lets the connector run for real before the cloud gateway exists — and doubles as the executable specification for whoever builds it. Full request/response reference with verified curls: `API.md`.

---

## 7. Failure stories, end to end

Each is a chaos test in `test/` — a proof, not a hope.

**The internet dies mid-day.** Ticks keep reading Tally; batches land in the outbox; the cursor advances; "pending upload batches" climbs. Network returns → flush delivers oldest-first, counter drains, idempotency absorbs overlap. Nothing lost, nothing duplicated, nobody did anything.

**The PC bluescreens mid-sync.** In-flight transactions committed fully or not at all (SQLite's job). On reboot, resume from the persisted cursor; worst case one page re-sends, invisible behind the (guid, alterId) key.

**The operator switches companies in Tally.** Each company has its own GUID-keyed cursor, so the new company syncs from its own bookmark. (Under the old shared cursor this produced the worst signature possible — errorless, healthy-looking, total silence — which is why the doctor now checks cursor-vs-max explicitly.)

**Tally rejects an import** (unknown ledger, closed period). Acked `failed` with Tally's reason, parked server-side for a human; every other command still processes this tick.

**Tally errors on our query** (LINEERROR — e.g., a field name this version doesn't know). Hard error, minimal-fields fallback kicks in, sync proceeds degraded-but-loud. Never reads as "no changes."

**The gateway rejects a batch as malformed.** Poison: parked 24 h, alarmed, never deleted; fresh data flows past.

**Someone deletes `connector.db`.** Cursors reset → history re-streams → gateway dedupes it all. Down-sync dedupe survives via the Tally-side external-ID and ledger-name lookups. The system heals from total local amnesia.

**Tally returns a field shape we've never seen.** The page is refused with the raw record attached; the record becomes a golden fixture and a coercion fix. This loop has now closed three real incidents: attributed ALTERID with comma grouping, the empty attributed NARRATION, and the version-specific ledger fields.

---

## 8. Glossary

- **AlterID** — Tally's per-company change counter, stamped on every record at last modification.
- **Cursor** — highest AlterID durably handed off, per company **GUID** per entity.
- **Tick** — one bounded run of ping → flush → up-sync → down-sync.
- **Outbox** — persisted queue of batches awaiting gateway delivery ("pending upload batches").
- **Poison batch** — gateway-rejected (4xx) batch; parked 24 h, never deleted.
- **Backoff with jitter** — retry delays doubling (2 s → 5 min cap) with randomness so a fleet doesn't stampede a recovering server.
- **Idempotency key** — (company GUID, guid, alterId) up-sync; external command ID (vouchers) or ledger name (ledger creates) down-sync.
- **FETCH / minimal fetch** — the explicit field list Tally returns; the reduced fallback list used when the full one fails on a given Tally version.
- **LINEERROR** — Tally's error document; must never be read as an empty result.
- **[ext:...] / UDF stamp** — the cloud command's ID written into every created voucher; enables Tally-side dedupe and echo recognition.
- **Hint** — a data-free POST from Tally's TDL add-on that pulls the next poll forward; fail-open by contract.
- **Golden fixture** — a captured real-Tally response checked into `fixtures/` and locked in by tests.

# tally-connector

Production two-way sync connector between merchant Tally installations and the cloud Connector Gateway API. Implements the [tech spec](../tally-connector-tech-spec.md); section references below point at it.

## Status — Phase 1 (core engine) complete

- ✅ TypeScript scaffold, strict mode
- ✅ SQLite state store on Node's built-in `node:sqlite` — zero native deps, no Python/MSVC needed on any machine (WAL, transactional cursor+outbox transitions) — spec §5.3
- ✅ Tally adapter: ping, paged ALTERID fetch, voucher import with UDF external-id, ext-id dedupe lookup — §5.1
- ✅ Cloud client: device-token auth, retryable/non-retryable error split, backoff w/ jitter, heartbeat + remote config — §5.4, §6
- ✅ Sync engine: outbox-owned delivery, atomic queue+advance, two-layer down-sync dedupe, poison-batch parking — §5.2, §7
- ✅ Tally + Cloud simulators with runtime fault injection — §13
- ✅ 20 tests: golden-file XML suite + chaos suite (cloud outage, crash-replay, Tally down, malformed XML, poison batch, lost local state, restart durability)
- ✅ TDL hint listener (fail-open `<STATUS>1</STATUS>`) + the optional `tdl/tally-connector-hint.tdl` add-on — §4.1
- ✅ CI: typecheck, tests, smoke soak, Windows build job
- ⬜ Phase 0 items needing a real Tally lab: golden fixtures captured from real TallyPrime/ERP 9, UDF round-trip validation, multi-company `List of Companies`
- ✅ Electron tray app: brand-styled status window, "Sync now", start-at-login, NSIS one-click installer config (`electron/`, `electron-builder.yml`)
- ⬜ Phase 2 remaining: code signing in CI, auto-update wiring (electron-updater against the publish URL), pairing flow, deletion reconciliation job

## Documentation

Read `WORKFLOWS.md` for a plain-language, in-depth walkthrough of every logical workflow (ticks, cursors, outbox, dedupe, failure stories).

## Layout

```
src/
  config.ts          env + remote config merge
  logger.ts          structured logs + diagnostics ring buffer
  store.ts           SQLite: cursors, outbox, imported_ids
  tally/xml.ts       envelope builders/parsers (ALL Tally quirks live here)
  tally/adapter.ts   typed HTTP layer, error taxonomy
  cloud/client.ts    gateway API client, backoff
  sync/engine.ts     the correctness core — read its header comment first
  service.ts         tick loop, heartbeat, TDL hint endpoint
simulator/           Tally + cloud test doubles w/ fault switches
  src/gateway-lite.ts  runnable lightweight gateway (full contract + /entries, /commands)
test/                golden-file + chaos suites
tdl/                 optional v1.1 push-assist add-on
electron/            tray app shell (main.js, preload, status window)
electron-builder.yml NSIS installer + update-feed config
fixtures/            golden XML (replace with lab captures in Phase 0)
```

## Run

Requires Node >= 22.13 (uses the built-in `node:sqlite`; on 22.x you'll see a harmless ExperimentalWarning — it's stable from Node 24).

```bash
npm install
npm test                                  # full suite, <2s

# against real Tally + a gateway:
TALLY_URL=http://localhost:9000 \
API_BASE=https://connector-gw.internal \
DEVICE_TOKEN=... \
HINT_PORT=9797 \
npm run dev
```

## Invariants the tests enforce

1. Every Tally delta reaches the cloud exactly once *as observed by the cloud* (at-least-once transport + `(company, guid, alterId)` idempotency).
2. The cursor never advances without a durable handoff (direct push or outbox row) — enforced atomically in `Store.queueAndAdvance`.
3. A cloud-originated command is imported into Tally at most once, surviving lost acks *and* total loss of local state (UDF/narration ext-id lookup).
4. No failure mode (Tally down, cloud down, malformed XML, poison batch) blocks unrelated data from flowing.

Any PR touching `src/sync` or `src/store` must keep the chaos suite green — these tests are the spec's §7 guarantees, executable.

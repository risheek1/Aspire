const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('connector', {
  status: () => ipcRenderer.invoke('connector:status'),
  syncNow: () => ipcRenderer.invoke('connector:syncNow'),
  startActivation: (loginId, merchantId) => ipcRenderer.invoke('connector:startActivation', loginId, merchantId),
  completePin: (pin) => ipcRenderer.invoke('connector:completePin', pin),
});

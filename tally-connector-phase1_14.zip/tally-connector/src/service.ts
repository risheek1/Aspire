import http from 'node:http';
import { loadConfig, applyRemoteConfig, ConnectorConfig } from './config';
import { Logger } from './logger';
import { Store, Entity } from './store';
import { TallyAdapter } from './tally/adapter';
import { CloudClient } from './cloud/client';
import type { BackendClient } from './cloud/backend';
import { AccountingIntegrationsClient } from './cloud/aiClient';
import { PassportAuth } from './cloud/passportAuth';
import { KvTokenStorage } from './cloud/tokenStorage';
import { SyncEngine } from './sync/engine';

export type ActivationState = 'not_required' | 'needs_registration' | 'needs_pin' | 'activated' | 'token_expired';

const VERSION = '1.0.0-alpha.1';

export class ConnectorService {
  private cfg: ConnectorConfig;
  private log: Logger;
  private store: Store;
  private engine!: SyncEngine;
  private cloud!: BackendClient;
  private auth?: PassportAuth;
  private pinRequested = false;
  private timer?: NodeJS.Timeout;
  private ticking = false;
  private hintServer?: http.Server;
  private lastReport: import('./sync/engine').TickReport | null = null;
  private lastTickAt: number | null = null;
  private tally: TallyAdapter;
  private companies: import('./tally/xml').CompanyInfo[] = [];
  private tickCount = 0;

  constructor(cfg = loadConfig(), log?: Logger) {
    this.cfg = cfg;
    this.log = log ?? new Logger(cfg.logLevel);
    this.store = new Store(cfg.dbPath);
    this.tally = new TallyAdapter({ url: cfg.tallyUrl });
    if (cfg.backend === 'ai') {
      // Client credentials: per-install creds provisioned at registration time
      // (stored in kv) take precedence; build-config creds are the fallback
      // for the shared-badge model. Supports either outcome of the
      // client-registration decision without a code change.
      const clientId = this.store.kvGet('client_id') || cfg.clientId;
      const clientSecret = this.store.kvGet('client_secret') || cfg.clientSecret;
      this.auth = new PassportAuth(
        { authBase: cfg.authBase, clientId, clientSecret },
        new KvTokenStorage(this.store),
      );
      const integrationId = this.store.kvGet('integration_id');
      if (integrationId) this.buildEngine(this.makeAiClient(integrationId));
    } else {
      this.buildEngine(new CloudClient(cfg.apiBase, cfg.deviceToken));
    }
  }

  private makeAiClient(integrationId: string): AccountingIntegrationsClient {
    return new AccountingIntegrationsClient(
      { apiBase: this.cfg.aiApiBase, integrationId },
      this.auth!,
    );
  }

  private buildEngine(cloud: BackendClient) {
    this.cloud = cloud;
    this.engine = new SyncEngine(this.tally, cloud, this.store, this.log, {
      companies: this.cfg.companies,
      entities: ['vouchers', 'ledgers', 'stockitems'] as Entity[],
      pageSize: this.cfg.pageSize,
      maxPagesPerTick: 20,
    });
  }

  // ---------------- activation (production backend) ----------------

  getActivationState(): ActivationState {
    if (this.cfg.backend !== 'ai') return 'not_required';
    if (!this.store.kvGet('integration_id')) {
      return this.pinRequested ? 'needs_pin' : 'needs_registration';
    }
    try {
      this.auth!.bearer();
      return 'activated';
    } catch {
      return this.pinRequested ? 'needs_pin' : 'token_expired';
    }
  }

  /** Store per-install client credentials (e.g. from a future dynamic
   *  registration / setup-code exchange) and rebuild auth around them. */
  provisionClientCredentials(clientId: string, clientSecret: string) {
    this.store.kvSet('client_id', clientId);
    this.store.kvSet('client_secret', clientSecret);
    this.auth = new PassportAuth(
      { authBase: this.cfg.authBase, clientId, clientSecret },
      new KvTokenStorage(this.store),
    );
  }

  /** Step 1 — sends a PIN to the merchant. Never auto-retried. */
  async startActivation(loginId: string, merchantId: string): Promise<void> {
    await this.auth!.authorize(loginId, merchantId);
    this.store.kvSet('login_id', loginId);
    this.store.kvSet('merchant_id', merchantId);
    this.pinRequested = true;
    this.log.info('activation PIN requested', { loginId });
  }

  /** Step 2 — PIN -> token -> integrate (bound to the open Tally company GUID). */
  async completeActivation(pin: string): Promise<void> {
    const loginId = this.store.kvGet('login_id')!;
    const merchantId = this.store.kvGet('merchant_id')!;
    await this.auth!.exchangePin(loginId, merchantId, pin);
    this.pinRequested = false;

    let integrationId = this.store.kvGet('integration_id');
    if (!integrationId) {
      const companies = await this.tally.listCompanies(); // Tally must be open
      const guid = companies[0]?.guid;
      if (!guid) throw new Error('Open your company in Tally first — activation binds to it.');
      const client = this.makeAiClient('pending');
      integrationId = await client.integrate(loginId, guid);
      this.store.kvSet('integration_id', integrationId);
      this.store.kvSet('company_guid', guid);
      this.log.info('integration registered', { integrationId, companyGuid: guid });
    }
    this.buildEngine(this.makeAiClient(integrationId));
    this.makeAiClient(integrationId)
      .reportVersion(merchantId, VERSION)
      .catch((e) => this.log.warn('version report failed', { message: e?.message }));
    this.schedule(0);
  }

  start() {
    this.log.info('connector starting', { version: VERSION, tally: this.cfg.tallyUrl, backend: this.cfg.backend });
    if (this.getActivationState() === 'activated' || this.cfg.backend === 'lite') {
      this.schedule(0);
    } else {
      this.log.info('activation required before syncing');
    }
    if (this.cfg.hintPort > 0) this.startHintListener();
  }

  private schedule(delayMs: number) {
    clearTimeout(this.timer); // never leave two live timers (hint + finally)
    this.timer = setTimeout(() => void this.runTick(), delayMs);
  }

  /** Serialized: a hint arriving mid-tick doesn't start a concurrent tick. */
  private async runTick() {
    if (this.cfg.backend === 'ai' && this.getActivationState() !== 'activated') {
      return; // paused until (re-)activation; completeActivation reschedules
    }
    if (this.ticking) return this.schedule(this.cfg.pollIntervalMs);
    this.ticking = true;
    try {
      const report = await this.engine.tick();
      this.lastReport = report;
      this.lastTickAt = Date.now();
      this.tickCount++;
      if (report.tallyUp && (this.companies.length === 0 || this.tickCount % 15 === 0)) {
        try {
          this.companies = await this.tally.listCompanies();
        } catch (e: any) {
          this.log.debug('company info fetch failed', { message: e?.message });
        }
      }
      if (!report.tallyUp) this.companies = [];
      this.log.debug('tick', report as unknown as Record<string, unknown>);

      const remote = await (this.cloud.heartbeat?.bind(this.cloud) ?? (async () => ({})))({
          version: VERSION,
          tallyUp: report.tallyUp,
          outboxDepth: this.store.outboxDepth(),
          cursors: {},
          errors: report.errors,
        }).catch(() => ({}) as Record<string, never>);
      if (Object.keys(remote).length) {
        this.cfg = applyRemoteConfig(this.cfg, remote);
        if (remote.logLevel) this.log.setLevel(remote.logLevel);
      }
    } catch (e: any) {
      this.log.error(`tick crashed: ${e?.message ?? e}`, { stack: String(e?.stack ?? '').split('\n').slice(0, 4).join(' | ') });
    } finally {
      this.ticking = false;
      this.schedule(this.cfg.pollIntervalMs);
    }
  }

  /**
   * v1.1 push-assist (§4.1): Tally's TDL add-on posts here On: Form Accept.
   * FAIL-OPEN CONTRACT: respond <STATUS>1</STATUS> unconditionally and
   * instantly — Tally blocks form acceptance until STATUS=1, so this endpoint
   * must never compute anything before replying. The hint only pulls the next
   * poll forward; the ALTERID cursor remains the source of truth.
   */
  private startHintListener() {
    this.hintServer = http.createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end('<ENVELOPE><STATUS>1</STATUS></ENVELOPE>');
      clearTimeout(this.timer);
      this.schedule(250); // debounce burst of saves into one near-immediate tick
    });
    this.hintServer.listen(this.cfg.hintPort, '127.0.0.1', () =>
      this.log.info('TDL hint listener up', { port: this.cfg.hintPort }),
    );
  }

  /** Consumed by the tray UI over IPC. */
  getStatus() {
    return {
      version: VERSION,
      backend: this.cfg.backend,
      activationState: this.getActivationState(),
      authExpiringSoon: this.auth?.expiringSoon(1) ?? false,
      tallyUp: this.lastReport?.tallyUp ?? false,
      lastTickAt: this.lastTickAt,
      outboxDepth: this.store.outboxDepth(),
      companies: this.companies,
      lastReport: this.lastReport,
      logs: this.log.snapshot().slice(-50),
    };
  }

  /** Tray "Sync now" — pulls the next tick forward, serialized like hints. */
  syncNow() {
    clearTimeout(this.timer);
    this.schedule(0);
  }

  async stop() {
    clearTimeout(this.timer);
    this.hintServer?.close();
    this.store.close();
  }
}

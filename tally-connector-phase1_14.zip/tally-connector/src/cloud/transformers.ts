/**
 * Pure functions mapping between the connector's internal records and the
 * accounting-integrations wire shapes CONFIRMED in §1A of the integration
 * plan (captured curls). Where only prose docs exist (fetch responses for
 * bills), the shape is taken from the reference doc and flagged.
 */
import type { ChangedRecord } from '../tally/xml';
import type { PendingCommand } from './backend';
import { toText } from '../tally/xml';

const t = (r: ChangedRecord, k: string) => toText(r.raw[k]);

// ---------- masters (up-sync) ----------

/** Flat Group records -> nested ledger_groups tree (confirmed shape). */
export function toLedgerGroupsTree(records: ChangedRecord[]): any[] {
  interface Node {
    group_id: string;
    group_name: string;
    group_parent_name: string;
    group_parent_id?: string;
    children: Node[];
  }
  const nodes: Node[] = records.map((r) => ({
    group_id: r.guid,
    group_name: t(r, 'NAME'),
    group_parent_name: t(r, 'PARENT') || 'Primary',
    children: [],
  }));
  const byName = new Map(nodes.map((n) => [n.group_name, n]));
  const roots: Node[] = [];
  for (const n of nodes) {
    const parent = byName.get(n.group_parent_name);
    if (parent && parent !== n) {
      n.group_parent_id = parent.group_id;
      parent.children.push(n);
    } else {
      roots.push(n);
    }
  }
  const finalize = (n: Node): any => {
    const { children, ...rest } = n;
    const out: any = { ...rest };
    if (children.length) out.sub_groups = children.map(finalize);
    return out;
  };
  return roots.map(finalize);
}

/** Ledgers -> chart-of-accounts entries. */
export function toChartOfAccounts(records: ChangedRecord[]): any[] {
  return records.map((r) => ({
    ledger_id: r.guid,
    ledger_name: t(r, 'NAME'),
    group_name: t(r, 'PARENT') || 'Primary',
    gstin: t(r, 'PARTYGSTIN') || undefined,
    state: t(r, 'LEDSTATENAME') || undefined,
    email: t(r, 'EMAIL') || undefined,
  }));
}

/** Stock items -> items[] with GST-treatment mapping (confirmed shape). */
export function toItems(records: ChangedRecord[]): any[] {
  return records.map((r) => {
    const igst = t(r, 'IGSTRATE');
    const gstApplicable = igst !== '' && Number(igst) > 0;
    return {
      id: r.guid,
      name: t(r, 'NAME'),
      group_name: t(r, 'PARENT') || 'Primary',
      unit: t(r, 'BASEUNITS') || 'Nos',
      hsn_or_sac: t(r, 'HSNCODE') || undefined,
      gst_treatment: igst === '' ? undefined : gstApplicable ? 'Taxable' : 'Exempt',
      igst_rate: igst || undefined,
      cgst_rate: igst ? String(Number(igst) / 2) : undefined,
      sgst_rate: igst ? String(Number(igst) / 2) : undefined,
    };
  });
}

/** Cost centres (confirmed shape). */
export function toCostCentres(records: ChangedRecord[]): any[] {
  return records.map((r) => ({
    cost_centre_id: r.guid,
    cost_centre_name: t(r, 'NAME'),
    cost_centre_category: t(r, 'CATEGORY') || 'Primary Cost Category',
  }));
}

/** Voucher types (reference-doc shape). */
export function toVoucherTypes(records: ChangedRecord[]): any[] {
  return records.map((r) => ({
    voucher_external_id: r.guid,
    name: t(r, 'NAME'),
    type: (t(r, 'PARENT') || '').toLowerCase() || undefined,
  }));
}

// ---------- down-sync (fetched payload -> engine command) ----------

export function vendorToCommand(v: any): PendingCommand {
  return {
    id: v.id,
    company: '',
    kind: 'ledger',
    action: 'create',
    name: v.name || v.external_name,
    parent: v.external_group_name || 'Sundry Creditors',
    gstin: v.gstin || undefined,
    email: v.email || undefined,
    phone: v.contact || undefined,
    state: v.state || undefined,
    ackMeta: { entityType: 'vendors', rxId: v.id },
  };
}

export function itemToCommand(i: any): PendingCommand {
  return {
    id: i.id,
    company: '',
    kind: 'stockitem',
    action: 'create',
    name: i.external_name || i.name,
    parent: i.external_group_name || 'Primary',
    baseUnits: i.unit || 'Nos',
    hsn: i.hsn_or_sac || undefined,
    ackMeta: { entityType: 'items', rxId: i.id },
  };
}

export function advanceToCommand(a: any): PendingCommand {
  const contact = a.contact?.external_name;
  const bank = a.source_account?.external_name;
  const payable = Number(a.payable_amount ?? a.amount);
  const entries = [
    { ledger: contact, amount: -Number(a.amount) }, // debit vendor (advance asset)
    { ledger: bank, amount: payable }, // credit bank
  ];
  for (const tds of a.tds_taxes ?? []) {
    entries.push({ ledger: tds.tds_category?.external_name, amount: Number(tds.tds_amount) });
  }
  return {
    id: a.id,
    company: '',
    kind: 'voucher',
    voucherType: 'Payment',
    date: (a.created_date ?? '').replace(/-/g, ''),
    number: a.id,
    narration: a.narration || `Advance ${a.id}`,
    entries,
    ackMeta: { entityType: 'advances', rxId: a.id, contact: a.contact },
  };
}

/** v1: flat ledger-leg representation of a bill (inventory/cost-centre XML is
 *  the P3 deep-dive; this books the amounts correctly without stock entries). */
export function billToCommand(wrapper: any): PendingCommand {
  const b = wrapper.bill ?? wrapper;
  const entries: { ledger: string; amount: number }[] = [];
  for (const li of b.line_items ?? []) {
    entries.push({ ledger: li.purchase_ledger_name || li.external_name, amount: -Number(li.amount) }); // debit expense
    for (const gk of ['igst', 'cgst', 'sgst'] as const) {
      if (li[gk]?.amount) entries.push({ ledger: `${gk.toUpperCase()} Input`, amount: -Number(li[gk].amount) }); // debit input GST
    }
  }
  const tds = Number(b.tds_amount ?? 0);
  if (tds) entries.push({ ledger: b.tds_category?.external_name ?? 'TDS Payable', amount: tds }); // credit TDS
  const payable = Number(b.total_amount) - tds;
  entries.push({ ledger: b.contact?.external_name, amount: payable }); // credit vendor
  return {
    id: b.id,
    company: '',
    kind: 'voucher',
    voucherType: b.voucher_info?.external_name || b.voucher_type || 'Purchase',
    date: (b.invoice_date ?? '').replace(/-/g, ''),
    number: b.invoice_number,
    narration: `Bill ${b.invoice_number}`,
    entries,
    ackMeta: {
      entityType: 'bills',
      rxId: b.id,
      syncEntryId: wrapper.sync_entry_id,
      contact: b.contact,
      lineItems: b.line_items,
      payments: b.payments,
    },
  };
}

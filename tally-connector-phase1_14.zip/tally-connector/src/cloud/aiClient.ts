/**
 * BackendClient for the production accounting-integrations service
 * (https://accounting-integrations.razorpay.com, /v1/tally/* surface).
 *
 * Wire shapes per §1A of the integration plan (captured curls). Fetches are
 * DESTRUCTIVE server-side (entries never re-delivered), so redeliversPending
 * = false — the engine persists fetched commands to the inbox before acting.
 */
import type { Entity } from '../store';
import type { ChangedRecord } from '../tally/xml';
import type { BackendClient, PendingCommand, AckDetail } from './backend';
import { PassportAuth, AuthExpiredError } from './passportAuth';
import { CloudError } from './client';
import * as T from './transformers';

export interface AIClientOptions {
  apiBase: string; // https://accounting-integrations.razorpay.com
  integrationId: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
  maxPagesPerFetch?: number;
}

const MASTER_ROUTES: Partial<Record<Entity | string, { path: string; wrap: (r: ChangedRecord[]) => any }>> = {
  ledgers: { path: '/v1/tally/send/chart-of-accounts', wrap: (r) => ({ chart_of_accounts: T.toChartOfAccounts(r) }) },
  ledgergroups: { path: '/v1/tally/send/chart-of-account-groups', wrap: (r) => ({ ledger_groups: T.toLedgerGroupsTree(r) }) },
  stockitems: { path: '/v1/tally/send/items', wrap: (r) => ({ items: T.toItems(r) }) },
  stockgroups: { path: '/v1/tally/send/item-groups', wrap: (r) => ({ item_groups: T.toLedgerGroupsTree(r) }) },
  costcentres: { path: '/v1/tally/send/cost-centres', wrap: (r) => ({ cost_centres: T.toCostCentres(r) }) },
  vouchertypes: { path: '/v1/tally/sync/voucher-types', wrap: (r) => ({ accounting_vouchers: T.toVoucherTypes(r) }) },
};

export class AccountingIntegrationsClient implements BackendClient {
  readonly redeliversPending = false;
  private fetchImpl: typeof fetch;

  constructor(
    private opts: AIClientOptions,
    private auth: PassportAuth,
  ) {
    this.fetchImpl = opts.fetchImpl ?? fetch;
  }

  private async req(method: string, path: string, body?: unknown): Promise<any> {
    let bearer: string;
    try {
      bearer = this.auth.bearer();
    } catch (e) {
      if (e instanceof AuthExpiredError) throw new CloudError('CLOUD_AUTH', e.message, false);
      throw e;
    }
    const ctl = new AbortController();
    const tm = setTimeout(() => ctl.abort(), this.opts.timeoutMs ?? 20000);
    try {
      const res = await this.fetchImpl(`${this.opts.apiBase}${path}`, {
        method,
        headers: { Authorization: bearer, 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: ctl.signal,
      });
      if (res.status === 401 || res.status === 403) throw new CloudError('CLOUD_AUTH', `auth rejected (${res.status})`, false);
      if (!res.ok) throw new CloudError('CLOUD_REJECTED', `HTTP ${res.status}`, res.status >= 500);
      const data = await res.json().catch(() => ({}));
      // Backend convention: handler errors come back as { success: false }.
      if (data && data.success === false) throw new CloudError('CLOUD_REJECTED', 'backend returned success:false', false);
      return data;
    } catch (e: any) {
      if (e instanceof CloudError) throw e;
      throw new CloudError('CLOUD_UNREACHABLE', e?.message ?? 'network error', true);
    } finally {
      clearTimeout(tm);
    }
  }

  // ---------- registration & lifecycle ----------

  async integrate(userEmail: string, companyGuid: string): Promise<string> {
    const data = await this.req('POST', '/v1/tally/integrate', { user_email: userEmail, company_id: companyGuid });
    return data.integration_id;
  }

  reportVersion(merchantId: string, version: string): Promise<void> {
    return this.req('POST', '/v1/tally/plugin/version', { merchant_id: merchantId, plugin_version: version });
  }

  // ---------- BackendClient: masters up-sync ----------

  async pushBatch(entity: Entity | string, _company: string, records: ChangedRecord[]): Promise<void> {
    const route = MASTER_ROUTES[entity];
    if (!route) return; // entities without a destination (e.g. vouchers) are skipped
    await this.req('POST', route.path, { integration_id: this.opts.integrationId, ...route.wrap(records) });
  }

  // ---------- BackendClient: down-sync ----------

  async fetchPending(): Promise<PendingCommand[]> {
    const out: PendingCommand[] = [];
    const q = `?integration_id=${encodeURIComponent(this.opts.integrationId)}`;
    const maxPages = this.opts.maxPagesPerFetch ?? 5;

    // Vendors first, then items, so bills never reference missing masters.
    for (const [path, key, xf] of [
      ['/v1/tally/fetch/vendors', 'vendors', T.vendorToCommand],
      ['/v1/tally/fetch/items', 'items', T.itemToCommand],
    ] as const) {
      for (let page = 0; page < maxPages; page++) {
        const data = await this.req('GET', `${path}${q}`);
        for (const v of data?.[key] ?? []) out.push(xf(v));
        if (!data?.has_more) break;
        if ((data?.[key] ?? []).length === 0) break; // lock-busy: try next tick
      }
    }

    const bills = await this.req('GET', `/v1/tally/fetch/bills${q}`);
    for (const w of bills?.invoices ?? []) out.push(T.billToCommand(w));

    const adv = await this.req('GET', `/v1/tally/fetch/vendor-advances${q}`);
    for (const a of adv?.advances ?? adv?.vendor_advances ?? []) out.push(T.advanceToCommand(a));

    return out;
  }

  /** Ack routing per entity type, using the §1A confirmed shapes. Sent as
   *  single-element bulk calls (batching is a later optimization). */
  async ack(cmd: PendingCommand, status: 'imported' | 'duplicate' | 'failed', detail?: AckDetail): Promise<void> {
    const meta = (cmd.ackMeta ?? {}) as any;
    const ok = status !== 'failed'; // duplicate = already in Tally = success for the backend
    const failureReason = ok ? undefined : String(detail?.message ?? detail?.code ?? 'failed');
    const base = { integration_id: this.opts.integrationId };

    switch (meta.entityType) {
      case 'vendors':
        return this.req('POST', '/v1/tally/ack/vendors', {
          ...base,
          vendors: [{ rx_id: meta.rxId, external_id: String(detail?.externalId ?? ''), external_name: cmd.name, success: ok, ...(failureReason ? { failure_reason: failureReason } : {}) }],
        });
      case 'items':
        return this.req('POST', '/v1/tally/ack/items', {
          ...base,
          items: [{ rx_id: meta.rxId, external_id: String(detail?.externalId ?? ''), external_name: cmd.name, success: ok, ...(failureReason ? { failure_reason: failureReason } : {}) }],
        });
      case 'advances':
        return this.req('POST', '/v1/tally/ack/vendor-advances', {
          ...base,
          advances: [{
            rx_id: meta.rxId,
            external_transaction_id: String(detail?.externalId ?? ''),
            success: ok,
            action: 'CREATE',
            ...(meta.contact ? { contact: [{ rx_id: meta.contact.rx_id ?? '', external_id: meta.contact.external_id ?? '', external_name: meta.contact.external_name ?? '' }] } : {}),
            ...(failureReason ? { failure_reason: failureReason } : {}),
          }],
        });
      case 'bills':
        // Shape flagged: vendors/advances diverged from prose docs; bills wire
        // shape is open question 7. Using reference-doc shape until captured.
        return this.req('POST', '/v1/tally/ack/bills', {
          ...base,
          bills_sync_responses: [{
            vendor_payment_id: meta.rxId,
            external_transaction_id: String(detail?.externalId ?? ''),
            success: ok,
            action: 'create',
            ...(failureReason ? { failure_reason: failureReason } : {}),
          }],
        });
      default:
        // Fallback: generic single-entity ack when a sync entry id is known.
        if (meta.syncEntryId) {
          return this.req('POST', `/v1/transactions/${encodeURIComponent(meta.syncEntryId)}/ack`, {
            ...base,
            external_id: String(detail?.externalId ?? ''),
            success: ok,
          });
        }
        throw new CloudError('CLOUD_REJECTED', `no ack route for command ${cmd.id}`, false);
    }
  }

  async heartbeat(): Promise<Record<string, unknown>> {
    return {}; // no heartbeat endpoint on this surface; version report covers startup
  }
}

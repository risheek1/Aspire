import type { Entity } from '../store';
import type { ChangedRecord } from '../tally/xml';

/**
 * The seam between the sync engine and whichever backend it speaks to.
 * Implementations: CloudClient (gateway-lite contract, dev/CI) and
 * AccountingIntegrationsClient (production /v1/tally/* surface).
 */
export interface PendingCommand {
  id: string;
  company: string;
  kind?: 'voucher' | 'ledger' | 'stockitem';
  // voucher fields
  date?: string;
  voucherType?: string;
  number?: string;
  narration?: string;
  entries?: { ledger: string; amount: number }[];
  // ledger/stockitem fields
  action?: 'create' | 'update';
  name?: string;
  parent?: string;
  newName?: string;
  openingBalance?: number;
  gstin?: string;
  email?: string;
  phone?: string;
  state?: string;
  creditPeriod?: string | number;
  billWise?: boolean;
  baseUnits?: string;
  hsn?: string;
  // ack routing (opaque to the engine; used by the client to route acks)
  ackMeta?: Record<string, unknown>;
}

export interface AckDetail {
  [k: string]: unknown;
}

export interface BackendClient {
  /** false = fetched items are never re-delivered by the backend; the engine
   *  must persist them to the local inbox before acting (crash safety). */
  readonly redeliversPending: boolean;

  pushBatch(entity: Entity, company: string, records: ChangedRecord[]): Promise<void>;
  fetchPending(): Promise<PendingCommand[]>;
  ack(cmd: PendingCommand, status: 'imported' | 'duplicate' | 'failed', detail?: AckDetail): Promise<void>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  heartbeat?(payload: any): Promise<any>;
}

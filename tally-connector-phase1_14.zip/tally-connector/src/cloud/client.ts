import type { Entity } from '../store';
import type { ChangedRecord, VoucherCommand } from '../tally/xml';

export class CloudError extends Error {
  constructor(
    public code: 'CLOUD_UNREACHABLE' | 'CLOUD_AUTH' | 'CLOUD_REJECTED',
    message: string,
    public retryable: boolean,
  ) {
    super(message);
  }
}

export interface PendingCommand extends Partial<VoucherCommand> {
  id: string;
  company: string;
  kind?: 'voucher' | 'ledger';
  // ledger-command fields (kind === 'ledger')
  action?: 'create' | 'update';
  name?: string;
  parent?: string;
  newName?: string;
  openingBalance?: number;
  gstin?: string;
  email?: string;
  phone?: string;
  state?: string;
  creditPeriod?: string | number;
  billWise?: boolean;
}

export interface HeartbeatPayload {
  version: string;
  tallyUp: boolean;
  outboxDepth: number;
  cursors: Record<string, number>;
  errors: Record<string, number>;
}

export interface RemoteConfig {
  pollIntervalMs?: number;
  pageSize?: number;
  logLevel?: 'debug' | 'info' | 'warn' | 'error';
}

import type { BackendClient, PendingCommand as BackendPendingCommand, AckDetail } from './backend';

export class CloudClient implements BackendClient {
  readonly redeliversPending = true;
  constructor(
    private baseUrl: string,
    private deviceToken: string,
    private fetchImpl: typeof fetch = fetch,
    private timeoutMs = 20000,
  ) {}

  private async req(method: string, path: string, body?: unknown): Promise<any> {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), this.timeoutMs);
    try {
      const res = await this.fetchImpl(`${this.baseUrl}${path}`, {
        method,
        headers: {
          Authorization: `Bearer ${this.deviceToken}`,
          'Content-Type': 'application/json',
        },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: ctl.signal,
      });
      if (res.status === 401 || res.status === 403) {
        throw new CloudError('CLOUD_AUTH', `auth failed (${res.status})`, false);
      }
      if (!res.ok) {
        // 4xx (other than auth) = our payload is bad, do not retry forever;
        // 5xx = server trouble, retryable.
        throw new CloudError('CLOUD_REJECTED', `HTTP ${res.status}`, res.status >= 500);
      }
      const text = await res.text();
      return text ? JSON.parse(text) : {};
    } catch (e: any) {
      if (e instanceof CloudError) throw e;
      throw new CloudError('CLOUD_UNREACHABLE', e?.message ?? 'network error', true);
    } finally {
      clearTimeout(t);
    }
  }

  /** Idempotent server-side on (company_guid, guid, alter_id). */
  pushBatch(entity: Entity, company: string, records: ChangedRecord[]): Promise<void> {
    return this.req('POST', `/v1/connector/${entity}/batch`, { company, records });
  }

  async fetchPending(): Promise<PendingCommand[]> {
    const data = await this.req('GET', '/v1/connector/pending');
    return data?.items ?? [];
  }

  ack(cmd: BackendPendingCommand | string, status: 'imported' | 'duplicate' | 'failed', detail?: AckDetail): Promise<void> {
    const id = typeof cmd === 'string' ? cmd : cmd.id;
    return this.req('POST', `/v1/connector/pending/${encodeURIComponent(id)}/ack`, { status, detail });
  }

  async heartbeat(payload: HeartbeatPayload): Promise<RemoteConfig> {
    const data = await this.req('POST', '/v1/connector/heartbeat', payload);
    return data?.config ?? {};
  }
}

/** Exponential backoff with full jitter, capped. */
export function backoffMs(attempts: number, baseMs = 2000, capMs = 5 * 60 * 1000): number {
  const exp = Math.min(capMs, baseMs * 2 ** Math.min(attempts, 10));
  return Math.floor(Math.random() * exp);
}

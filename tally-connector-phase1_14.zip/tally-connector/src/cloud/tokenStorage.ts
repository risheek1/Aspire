/**
 * kv-backed TokenStorage. In the packaged Electron app the JWT should
 * additionally be wrapped with safeStorage (DPAPI on Windows) before it
 * reaches SQLite; encryptor/decryptor hooks are injected for that.
 */
import type { Store } from '../store';
import type { TokenRecord, TokenStorage } from './passportAuth';

const KEY = 'passport_token';

export class KvTokenStorage implements TokenStorage {
  constructor(
    private store: Store,
    private encrypt: (s: string) => string = (s) => s,
    private decrypt: (s: string) => string = (s) => s,
  ) {}

  get(): TokenRecord | null {
    const raw = this.store.kvGet(KEY);
    if (!raw) return null;
    try {
      return JSON.parse(this.decrypt(raw));
    } catch {
      return null;
    }
  }

  set(t: TokenRecord): void {
    this.store.kvSet(KEY, this.encrypt(JSON.stringify(t)));
  }
}

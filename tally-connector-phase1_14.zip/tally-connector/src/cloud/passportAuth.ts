/**
 * Passport OAuth (PIN flow) against the Express auth service.
 *
 *   authorize(): sends a PIN to the merchant's registered email/phone.
 *   exchangePin(): PIN -> JWT (~7-day expiry). Stored via injected storage;
 *   in Electron this should be backed by safeStorage/DPAPI, in tests by kv.
 *
 * Never auto-retries authorize (each call re-sends a PIN to a human).
 */
export interface TokenRecord {
  accessToken: string;
  tokenType: string;
  expiresAt: number; // epoch ms
  publicToken?: string;
}

export interface TokenStorage {
  get(): TokenRecord | null;
  set(t: TokenRecord): void;
}

export interface PassportAuthOptions {
  authBase: string; // https://express.razorpay.com
  clientId: string;
  clientSecret: string;
  fetchImpl?: typeof fetch;
}

export class AuthExpiredError extends Error {
  code = 'AUTH_EXPIRED' as const;
}

const COMMON = { product: 'banking', feature: 'accounting_integration' };

export class PassportAuth {
  private fetchImpl: typeof fetch;
  constructor(
    private opts: PassportAuthOptions,
    private storage: TokenStorage,
  ) {
    this.fetchImpl = opts.fetchImpl ?? fetch;
  }

  private async post(path: string, body: unknown): Promise<any> {
    const res = await this.fetchImpl(`${this.opts.authBase}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(20000),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`auth ${path} failed: HTTP ${res.status} ${JSON.stringify(data).slice(0, 200)}`);
    return data;
  }

  /** Step 1 — triggers the PIN send. Call once per user action, never retried. */
  authorize(loginId: string, merchantId: string): Promise<void> {
    return this.post('/tally/v1/auth/authorize', {
      client_id: this.opts.clientId,
      login_id: loginId,
      merchant_id: merchantId,
      ...COMMON,
    });
  }

  /** Step 2 — PIN -> JWT, persisted. */
  async exchangePin(loginId: string, merchantId: string, pin: string): Promise<TokenRecord> {
    const data = await this.post('/tally/v1/auth/token', {
      client_id: this.opts.clientId,
      login_id: loginId,
      merchant_id: merchantId,
      pin,
      grant_type: 'tally_client_credentials',
      client_secret: this.opts.clientSecret,
      ...COMMON,
    });
    if (!data.access_token) throw new Error(`token exchange returned no access_token: ${JSON.stringify(data).slice(0, 200)}`);
    const rec: TokenRecord = {
      accessToken: data.access_token,
      tokenType: data.token_type || 'Bearer',
      expiresAt: Date.now() + Number(data.expires_in || 0) * 1000,
      publicToken: data.public_token,
    };
    this.storage.set(rec);
    return rec;
  }

  /** Bearer header value, or throws AuthExpiredError (engine surfaces the
   *  blocked state; the tray offers one-click re-PIN). */
  bearer(): string {
    const t = this.storage.get();
    if (!t || Date.now() >= t.expiresAt) throw new AuthExpiredError('token missing or expired — re-activation required');
    return `${t.tokenType} ${t.accessToken}`;
  }

  /** True when within warnDays of expiry — feeds the tray warning (day ~6). */
  expiringSoon(warnDays = 1): boolean {
    const t = this.storage.get();
    if (!t) return true;
    return t.expiresAt - Date.now() < warnDays * 24 * 3600 * 1000;
  }
}

/**
 * gateway-lite — a single-file, lightweight backend implementing the full
 * production connector contract, so the connector can run for real before the
 * cloud Connector Gateway service exists. Suitable for demos and pilots on a
 * trusted network; NOT the production gateway (no real auth, single process).
 *
 * Production contract (what the connector calls):
 *   POST /v1/connector/:entity/batch      idempotent ingest on (company,guid,alterId)
 *   GET  /v1/connector/pending            commands to write into Tally
 *   POST /v1/connector/pending/:id/ack    imported | duplicate | failed
 *   POST /v1/connector/heartbeat          health in, remote config out
 *
 * Lightweight extras (the tally-lite API, folded in):
 *   GET  /entries                         browse everything ingested (?type=&party=)
 *   POST /commands                        enqueue a voucher command for down-sync
 *                                         body: {date,voucherType,number,narration,
 *                                                company?, entries:[{ledger,amount}]}
 *   GET  /status                          counts + last heartbeat
 *
 * Persistence: one JSON file (GATEWAY_DB, default ./gateway-lite.json),
 * debounced writes. Run:  npm run gateway   (PORT default 8080)
 */
import http from 'node:http';
import { readFileSync, writeFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';

interface State {
  entries: Record<string, any>; // key company|guid|alterId
  pending: any[];
  acks: { id: string; status: string; detail?: unknown; at: string }[];
  lastHeartbeat: any;
}

export class LiteGateway {
  private server: http.Server;
  private state: State = { entries: {}, pending: [], acks: [], lastHeartbeat: null };
  private saveTimer?: NodeJS.Timeout;

  constructor(private dbPath?: string, private log: (m: string) => void = () => {}) {
    if (dbPath) {
      try {
        this.state = JSON.parse(readFileSync(dbPath, 'utf8'));
      } catch {
        /* fresh start */
      }
    }
    this.server = http.createServer((req, res) => this.handle(req, res));
  }

  listen(port = 0): Promise<number> {
    return new Promise((resolve) =>
      this.server.listen(port, '127.0.0.1', () => resolve((this.server.address() as any).port)),
    );
  }

  close() {
    this.server.close();
    this.persist(true);
  }

  seedCommand(cmd: any): string {
    const id = cmd.id ?? `cmd-${randomUUID().slice(0, 8)}`;
    this.state.pending.push({ company: '', ...cmd, id });
    this.persist();
    return id;
  }

  entryCount(): number {
    return Object.keys(this.state.entries).length;
  }

  private persist(now = false) {
    if (!this.dbPath) return;
    clearTimeout(this.saveTimer);
    const write = () => writeFileSync(this.dbPath!, JSON.stringify(this.state, null, 2));
    now ? write() : (this.saveTimer = setTimeout(write, 300));
  }

  private json(res: http.ServerResponse, code: number, body: unknown) {
    res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(body));
  }

  private handle(req: http.IncomingMessage, res: http.ServerResponse) {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', () => {
      try {
        const url = new URL(req.url ?? '/', 'http://x');
        const body = raw ? JSON.parse(raw) : {};
        this.route(req.method ?? 'GET', url, body, res);
      } catch (e: any) {
        this.json(res, 400, { error: e?.message });
      }
    });
  }

  private route(method: string, url: URL, body: any, res: http.ServerResponse) {
    const p = url.pathname;

    // ---- production contract ----
    const batch = p.match(/^\/v1\/connector\/(vouchers|ledgers|stockitems)\/batch$/);
    if (method === 'POST' && batch) {
      const entity = batch[1];
      let stored = 0;
      for (const r of body.records ?? []) {
        const key = `${body.company ?? ''}|${r.guid}|${r.alterId}`;
        if (this.state.entries[key]) continue; // idempotent: first write wins
        stored++;
        this.state.entries[key] = { entity, company: body.company ?? '', ...r, receivedAt: new Date().toISOString() };
      }
      this.persist();
      this.log(`ingest ${entity}: +${stored} new (${body.records?.length ?? 0} in batch, total ${this.entryCount()})`);
      return this.json(res, 200, { stored, total: this.entryCount() });
    }

    if (method === 'GET' && p === '/v1/connector/pending') {
      return this.json(res, 200, { items: this.state.pending });
    }

    const ack = p.match(/^\/v1\/connector\/pending\/(.+)\/ack$/);
    if (method === 'POST' && ack) {
      const id = decodeURIComponent(ack[1]);
      this.state.acks.push({ id, status: body.status, detail: body.detail, at: new Date().toISOString() });
      if (body.status === 'imported' || body.status === 'duplicate') {
        this.state.pending = this.state.pending.filter((c) => c.id !== id);
      }
      this.persist();
      this.log(`ack ${id}: ${body.status}`);
      return this.json(res, 200, {});
    }

    if (method === 'POST' && p === '/v1/connector/heartbeat') {
      this.state.lastHeartbeat = { ...body, at: new Date().toISOString() };
      this.persist();
      return this.json(res, 200, { config: {} });
    }

    // ---- lightweight extras (tally-lite API) ----
    if (method === 'GET' && p === '/entries') {
      let list = Object.values(this.state.entries);
      const type = url.searchParams.get('type');
      const party = url.searchParams.get('party');
      if (type) list = list.filter((e: any) => String(e.raw?.VOUCHERTYPENAME ?? e.entity) === type);
      if (party) list = list.filter((e: any) => String(e.raw?.PARTYLEDGERNAME ?? '').includes(party));
      return this.json(res, 200, { count: list.length, entries: list });
    }

    if (method === 'POST' && p === '/commands') {
      if (body.kind === 'ledger') {
        if (!body.name || !['create', 'update'].includes(body.action)) {
          return this.json(res, 400, { error: "ledger command needs name and action ('create'|'update')" });
        }
        if (body.action === 'create' && !body.parent) {
          return this.json(res, 400, { error: 'ledger create needs parent (the Tally group, e.g. "Sundry Debtors")' });
        }
        const id = this.seedCommand(body);
        this.log(`command queued ${id} (ledger ${body.action}: ${body.name})`);
        return this.json(res, 200, { id, queued: this.state.pending.length });
      }
      if (!body.date || !body.voucherType || !Array.isArray(body.entries)) {
        return this.json(res, 400, { error: 'need date, voucherType, entries[]' });
      }
      const sum = body.entries.reduce((s: number, e: any) => s + Number(e.amount || 0), 0);
      if (sum !== 0) return this.json(res, 400, { error: `entries must balance to 0 (got ${sum})` });
      const id = this.seedCommand(body);
      this.log(`command queued ${id} (${body.voucherType})`);
      return this.json(res, 200, { id, queued: this.state.pending.length });
    }

    if (method === 'GET' && p === '/status') {
      return this.json(res, 200, {
        entries: this.entryCount(),
        pending: this.state.pending.length,
        acks: this.state.acks.slice(-10),
        lastHeartbeat: this.state.lastHeartbeat,
      });
    }

    this.json(res, 404, { error: 'not found' });
  }
}

/* istanbul ignore next */
if (require.main === module) {
  const port = parseInt(process.env.PORT ?? '8080', 10);
  const db = process.env.GATEWAY_DB ?? './gateway-lite.json';
  const gw = new LiteGateway(db, (m) => console.log(`[gateway] ${m}`));
  gw.listen(port).then((p) => {
    console.log(`[gateway] lite gateway on http://127.0.0.1:${p} (state: ${db})`);
    console.log(`[gateway] connector env:  API_BASE=http://127.0.0.1:${p}  DEVICE_TOKEN=dev`);
    console.log(`[gateway] browse: GET /entries · create: POST /commands · health: GET /status`);
  });
}

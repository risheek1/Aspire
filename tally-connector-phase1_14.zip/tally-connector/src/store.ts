import { DatabaseSync } from 'node:sqlite';

export type Entity = 'vouchers' | 'ledgers' | 'stockitems';

export interface OutboxRow {
  id: number;
  company: string;
  entity: Entity;
  payload: string; // JSON batch
  attempts: number;
  next_retry_at: number; // epoch ms
}

/**
 * All durable connector state, on Node's built-in SQLite (node:sqlite) —
 * zero native npm dependencies, so installs never need Python/MSVC and the
 * packaged exe is fully self-contained. Every multi-step transition is a
 * SQLite transaction (WAL mode), which is what makes crash-during-sync safe:
 * "advance cursor + enqueue outbox" and "record import + note external id"
 * are each atomic.
 */
export class Store {
  private db: DatabaseSync;

  constructor(path: string) {
    this.db = new DatabaseSync(path);
    this.db.exec('PRAGMA journal_mode = WAL');
    this.db.exec('PRAGMA synchronous = NORMAL');
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS cursors (
        company TEXT NOT NULL, entity TEXT NOT NULL, alter_id INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (company, entity)
      );
      CREATE TABLE IF NOT EXISTS outbox (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company TEXT NOT NULL, entity TEXT NOT NULL, payload TEXT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0, next_retry_at INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS imported_ids (
        external_id TEXT PRIMARY KEY, tally_master_id TEXT, imported_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS inbox (
        id TEXT PRIMARY KEY, payload TEXT NOT NULL, received_at INTEGER NOT NULL
      );
    `);
  }

  getCursor(company: string, entity: Entity): number {
    const row = this.db
      .prepare('SELECT alter_id FROM cursors WHERE company=? AND entity=?')
      .get(company, entity) as { alter_id: number } | undefined;
    return row?.alter_id ?? 0;
  }

  setCursor(company: string, entity: Entity, alterId: number) {
    if (!Number.isInteger(alterId) || alterId < 0) {
      throw new Error(`refusing to write invalid cursor ${alterId} for ${entity} — upstream parse bug`);
    }
    this.db
      .prepare(
        `INSERT INTO cursors (company, entity, alter_id) VALUES (?,?,?)
         ON CONFLICT(company, entity) DO UPDATE SET alter_id=excluded.alter_id`,
      )
      .run(company, entity, alterId);
  }

  /** Cloud push failed: atomically persist the batch AND advance the cursor.
   *  From this point the outbox owns delivery; Tally is never re-read for it. */
  queueAndAdvance(company: string, entity: Entity, payload: unknown, newCursor: number) {
    this.db.exec('BEGIN IMMEDIATE');
    try {
      this.db
        .prepare('INSERT INTO outbox (company, entity, payload) VALUES (?,?,?)')
        .run(company, entity, JSON.stringify(payload));
      this.setCursor(company, entity, newCursor);
      this.db.exec('COMMIT');
    } catch (e) {
      this.db.exec('ROLLBACK');
      throw e;
    }
  }

  outboxDepth(): number {
    return (this.db.prepare('SELECT COUNT(*) c FROM outbox').get() as { c: number }).c;
  }

  /** Oldest due batch (FIFO per insertion order). */
  nextOutbox(now = Date.now()): OutboxRow | undefined {
    return this.db
      .prepare('SELECT * FROM outbox WHERE next_retry_at<=? ORDER BY id LIMIT 1')
      .get(now) as OutboxRow | undefined;
  }

  completeOutbox(id: number) {
    this.db.prepare('DELETE FROM outbox WHERE id=?').run(id);
  }

  failOutbox(id: number, backoffMs: number) {
    this.db
      .prepare('UPDATE outbox SET attempts=attempts+1, next_retry_at=? WHERE id=?')
      .run(Date.now() + backoffMs, id);
  }

  /** Destructive-fetch backends never re-deliver; persist fetched commands
   *  BEFORE acting so a crash between fetch and ack recovers from here. */
  inboxPut(id: string, payload: unknown) {
    this.db
      .prepare('INSERT OR IGNORE INTO inbox (id, payload, received_at) VALUES (?,?,?)')
      .run(id, JSON.stringify(payload), Date.now());
  }

  inboxAll(): { id: string; payload: any }[] {
    return (this.db.prepare('SELECT id, payload FROM inbox ORDER BY received_at').all() as any[]).map((r) => ({
      id: r.id,
      payload: JSON.parse(r.payload),
    }));
  }

  inboxDelete(id: string) {
    this.db.prepare('DELETE FROM inbox WHERE id=?').run(id);
  }

  kvGet(k: string): string | null {
    const r = this.db.prepare('SELECT v FROM kv WHERE k=?').get(k) as { v: string } | undefined;
    return r?.v ?? null;
  }

  kvSet(k: string, v: string) {
    this.db.prepare('INSERT INTO kv (k,v) VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k, v);
  }

  hasImported(externalId: string): boolean {
    return !!this.db.prepare('SELECT 1 FROM imported_ids WHERE external_id=?').get(externalId);
  }

  markImported(externalId: string, tallyMasterId?: string) {
    this.db
      .prepare(
        `INSERT OR IGNORE INTO imported_ids (external_id, tally_master_id, imported_at)
         VALUES (?,?,?)`,
      )
      .run(externalId, tallyMasterId ?? null, Date.now());
  }

  close() {
    this.db.close();
  }
}

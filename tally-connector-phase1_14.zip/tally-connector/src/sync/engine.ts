import type { Entity, Store } from '../store';
import { TallyAdapter, TallyError } from '../tally/adapter';
import { CloudError, backoffMs } from '../cloud/client';
import type { BackendClient, PendingCommand } from '../cloud/backend';
import type { Logger } from '../logger';

export interface EngineOptions {
  companies: string[]; // '' means "currently open company"
  entities: Entity[];
  pageSize: number;
  maxPagesPerTick: number;
}

export interface TickReport {
  tallyUp: boolean;
  pushedRecords: number;
  queuedBatches: number;
  flushedBatches: number;
  imported: number;
  importFailed: number;
  errors: Record<string, number>;
}

/**
 * One tick = one bounded unit of both-direction sync. Correctness rules:
 *
 *  UP:   fetch (AlterID > cursor) page -> hand off to cloud (direct push OR
 *        durable outbox enqueue) -> only then advance cursor. Handoff and
 *        cursor advance are atomic in the failure path (Store.queueAndAdvance),
 *        so a crash can only ever cause a re-read of the same page, which the
 *        server's (guid, alter_id) idempotency absorbs.
 *
 *  DOWN: for each pending command: local dedupe -> Tally-side dedupe fallback
 *        -> import -> markImported BEFORE ack. Crash between import and ack
 *        redelivers the command; both dedupe layers turn it into 'duplicate'.
 */
export class SyncEngine {
  constructor(
    private tally: TallyAdapter,
    private cloud: BackendClient,
    private store: Store,
    private log: Logger,
    private opts: EngineOptions,
  ) {}

  async tick(): Promise<TickReport> {
    const report: TickReport = {
      tallyUp: false,
      pushedRecords: 0,
      queuedBatches: 0,
      flushedBatches: 0,
      imported: 0,
      importFailed: 0,
      errors: {},
    };

    try {
      report.tallyUp = await this.tally.ping();
    } catch (e) {
      this.count(report, 'TALLY_UNREACHABLE');
      this.log.debug('tally unreachable; idling this tick');
      // Still try to flush outbox — cloud may be reachable while Tally is closed.
      await this.flushOutbox(report);
      return report;
    }

    await this.flushOutbox(report);
    await this.upSync(report);
    await this.downSync(report);
    return report;
  }

  // ---------------- UP ----------------

  private async flushOutbox(report: TickReport) {
    for (;;) {
      const row = this.store.nextOutbox();
      if (!row) return;
      try {
        const batch = JSON.parse(row.payload);
        await this.cloud.pushBatch(row.entity, row.company, batch.records);
        this.store.completeOutbox(row.id);
        report.flushedBatches++;
      } catch (e: any) {
        if (e instanceof CloudError && !e.retryable) {
          // Poison batch (schema rejection). Park it out of the hot path but
          // never delete data: mark with a long retry and scream in telemetry.
          this.store.failOutbox(row.id, 24 * 3600 * 1000);
          this.count(report, 'OUTBOX_POISON');
          this.log.error('outbox batch rejected as non-retryable; parked 24h', { id: row.id });
        } else {
          this.store.failOutbox(row.id, backoffMs(row.attempts));
          this.count(report, 'CLOUD_UNREACHABLE');
        }
        return; // preserve FIFO; retry next tick
      }
    }
  }

  /** Cursor + idempotency scope must be the company's IDENTITY (GUID), never
   *  the config string '' ("current company") — otherwise switching the open
   *  company in Tally silently parks the shared cursor above the new
   *  company's AlterIDs and sync appears dead with zero errors. */
  private async resolveCompanyKey(company: string): Promise<string> {
    if (company) return company; // explicitly configured
    try {
      const cos = await this.tally.listCompanies();
      if (cos[0]?.guid) return cos[0].guid;
    } catch {
      /* fall through */
    }
    return '';
  }

  private async upSync(report: TickReport) {
    for (const company of this.companiesOrDefault()) {
      const key = await this.resolveCompanyKey(company);
      for (const entity of this.opts.entities) {
        let pages = 0;
        for (;;) {
          if (pages >= this.opts.maxPagesPerTick) break; // bound tick duration
          const cursor = this.store.getCursor(key, entity);
          let page;
          try {
            page = await this.tally.fetchChanged(entity, company, cursor, this.opts.pageSize, (m) =>
              this.log.warn(m),
            );
            if (page.degraded) this.count(report, 'FETCH_DEGRADED');
          } catch (e: any) {
            this.count(report, e instanceof TallyError ? e.code : 'TALLY_BAD_RESPONSE');
            break;
          }
          if (page.records.length === 0) break;
          pages++;

          try {
            await this.cloud.pushBatch(entity, key, page.records);
            this.store.setCursor(key, entity, page.maxAlterId);
            report.pushedRecords += page.records.length;
          } catch (e: any) {
            // Durable handoff instead: outbox owns delivery from here.
            this.store.queueAndAdvance(key, entity, { records: page.records }, page.maxAlterId);
            report.queuedBatches++;
            this.count(report, 'CLOUD_UNREACHABLE');
          }
          if (!page.hasMore) break;
        }
      }
    }
  }

  // ---------------- DOWN ----------------

  private async downSync(report: TickReport) {
    // 1) Pull fresh commands. For destructive-fetch backends, persist each to
    //    the inbox BEFORE acting — the backend never re-delivers.
    let fresh: PendingCommand[] = [];
    try {
      fresh = await this.cloud.fetchPending();
    } catch (e: any) {
      this.count(report, e instanceof CloudError ? e.code : 'CLOUD_UNREACHABLE');
    }
    if (!this.cloud.redeliversPending) {
      for (const cmd of fresh) this.store.inboxPut(cmd.id, cmd);
      // Process the union: inbox first (recovered leftovers), then fresh —
      // inboxAll includes what we just put, so it IS the union, ordered.
      fresh = this.store.inboxAll().map((r) => r.payload as PendingCommand);
    }

    for (const cmd of fresh) {
      let done = false;
      try {
        if (this.store.hasImported(cmd.id)) {
          await this.cloud.ack(cmd, 'duplicate', { externalId: this.importedExternalId(cmd) });
          done = true;
          continue;
        }

        if (cmd.kind === 'ledger') {
          const exists = await this.tally.existsLedgerByName(cmd.company, cmd.name!);
          if (cmd.action === 'create' && exists) {
            this.store.markImported(cmd.id);
            await this.cloud.ack(cmd, 'duplicate', { externalId: cmd.name, reason: 'ledger already exists' });
            done = true;
            continue;
          }
          if (cmd.action === 'update' && !exists) {
            report.importFailed++;
            await this.cloud.ack(cmd, 'failed', { code: 'LEDGER_NOT_FOUND', message: `Ledger '${cmd.name}' not found`, name: cmd.name }).catch(() => {});
            done = true;
            continue;
          }
          const result = await this.tally.importLedger(cmd.company, cmd as any);
          this.store.markImported(cmd.id, cmd.name);
          await this.cloud.ack(cmd, 'imported', { ...result, externalId: cmd.name });
          report.imported++;
          done = true;
          continue;
        }

        if (cmd.kind === 'stockitem') {
          const exists = await this.tally.existsStockItemByName(cmd.company, cmd.name!);
          if (exists) {
            this.store.markImported(cmd.id);
            await this.cloud.ack(cmd, 'duplicate', { externalId: cmd.name, reason: 'stock item already exists' });
            done = true;
            continue;
          }
          const result = await this.tally.importStockItem(cmd.company, cmd as any);
          this.store.markImported(cmd.id, cmd.name);
          await this.cloud.ack(cmd, 'imported', { ...result, externalId: cmd.name });
          report.imported++;
          done = true;
          continue;
        }

        // voucher command (default kind)
        if (await this.tally.existsByExternalId(cmd.company, cmd.id)) {
          this.store.markImported(cmd.id);
          await this.cloud.ack(cmd, 'duplicate', { externalId: cmd.id });
          done = true;
          continue;
        }
        const result = await this.tally.importVoucher(cmd.company, cmd as any);
        this.store.markImported(cmd.id, result.lastVchId);
        await this.cloud.ack(cmd, 'imported', { ...result, externalId: result.lastVchId ?? cmd.id });
        report.imported++;
        done = true;
      } catch (e: any) {
        report.importFailed++;
        const code = e instanceof TallyError ? e.code : 'IMPORT_ERROR';
        this.count(report, code);
        // Only a genuine Tally REJECTION is terminal (ack failed + clear).
        // Transport-flavored errors — Tally unreachable/timeout mid-import, or
        // the cloud failing the ack itself — keep the command in the inbox
        // and retry next tick; dedupe makes the retry harmless.
        if (e instanceof TallyError && e.code === 'TALLY_IMPORT_REJECTED') {
          const acked = await this.cloud
            .ack(cmd, 'failed', { code, message: e?.message })
            .then(() => true)
            .catch(() => false);
          done = acked;
        }
      } finally {
        if (done && !this.cloud.redeliversPending) this.store.inboxDelete(cmd.id);
      }
    }
  }

  private importedExternalId(cmd: PendingCommand): string {
    return cmd.kind === 'ledger' || cmd.kind === 'stockitem' ? (cmd.name ?? cmd.id) : cmd.id;
  }

  private companiesOrDefault(): string[] {
    return this.opts.companies.length ? this.opts.companies : [''];
  }

  private count(report: TickReport, code: string) {
    report.errors[code] = (report.errors[code] ?? 0) + 1;
  }
}

import type { Entity } from '../store';
import * as X from './xml';

export class TallyError extends Error {
  constructor(
    public code: 'TALLY_UNREACHABLE' | 'TALLY_TIMEOUT' | 'TALLY_BAD_RESPONSE' | 'TALLY_IMPORT_REJECTED',
    message: string,
  ) {
    super(message);
  }
}

export interface TallyAdapterOptions {
  url: string;
  timeoutMs?: number;
  fetchImpl?: typeof fetch; // injectable for tests
}

export class TallyAdapter {
  private url: string;
  private timeoutMs: number;
  private fetchImpl: typeof fetch;

  constructor(opts: TallyAdapterOptions) {
    this.url = opts.url;
    this.timeoutMs = opts.timeoutMs ?? 30000;
    this.fetchImpl = opts.fetchImpl ?? fetch;
  }

  private async post(xml: string): Promise<string> {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), this.timeoutMs);
    try {
      const res = await this.fetchImpl(this.url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/xml;charset=utf-8' },
        body: xml,
        signal: ctl.signal,
      });
      if (!res.ok) throw new TallyError('TALLY_BAD_RESPONSE', `HTTP ${res.status}`);
      return await res.text();
    } catch (e: any) {
      if (e instanceof TallyError) throw e;
      if (e?.name === 'AbortError') throw new TallyError('TALLY_TIMEOUT', `timeout after ${this.timeoutMs}ms`);
      throw new TallyError('TALLY_UNREACHABLE', e?.message ?? 'connect failed');
    } finally {
      clearTimeout(t);
    }
  }

  async ping(): Promise<boolean> {
    const body = await this.post(X.pingEnvelope());
    return body.includes('<ENVELOPE') || body.includes('RESULT');
  }

  /** Companies currently loaded in Tally (name/guid/books-from). */
  async listCompanies(): Promise<X.CompanyInfo[]> {
    const body = await this.post(X.companiesEnvelope());
    try {
      return X.parseCompanies(body);
    } catch (e: any) {
      throw new TallyError('TALLY_BAD_RESPONSE', `company parse failed: ${e?.message}`);
    }
  }

  /** One page of changed records. If the full FETCH list yields a response we
   *  can't parse (field-name drift on some Tally versions), automatically
   *  degrade to the minimal field set for this call — sync must never stall
   *  because of an optional field. Degradation is surfaced via onWarn. */
  async fetchChanged(
    entity: Entity,
    company: string,
    sinceAlterId: number,
    pageSize: number,
    onWarn?: (msg: string) => void,
  ): Promise<{ records: X.ChangedRecord[]; hasMore: boolean; maxAlterId: number; degraded?: boolean }> {
    try {
      return await this.fetchChangedWith(entity, company, sinceAlterId, pageSize, undefined, onWarn);
    } catch (e: any) {
      if (!(e instanceof TallyError) || e.code !== 'TALLY_BAD_RESPONSE') throw e;
      const minimal = X.ENTITY_DEFS[entity].minimalFetch;
      onWarn?.(`${entity}: full FETCH failed (${e.message.slice(0, 160)}); retrying with minimal fields`);
      const r = await this.fetchChangedWith(entity, company, sinceAlterId, pageSize, minimal, onWarn);
      return { ...r, degraded: true };
    }
  }

  private async fetchChangedWith(
    entity: Entity,
    company: string,
    sinceAlterId: number,
    pageSize: number,
    fetchOverride: string | undefined,
    onWarn?: (msg: string) => void,
  ): Promise<{ records: X.ChangedRecord[]; hasMore: boolean; maxAlterId: number }> {
    const body = await this.post(X.fetchChangedEnvelope(entity, company, sinceAlterId, fetchOverride));
    if (body.includes('LINEERROR')) {
      throw new TallyError('TALLY_BAD_RESPONSE', `Tally LINEERROR: ${body.slice(0, 300)}`);
    }
    let records: X.ChangedRecord[];
    try {
      records = X.parseChanged(entity, body);
    } catch (e: any) {
      throw new TallyError('TALLY_BAD_RESPONSE', `parse failed: ${e?.message}`);
    }
    // Unknown shape (no COLLECTION node, no records): treat as empty but say
    // so — some Tally versions may omit the node when there are no changes,
    // so hard-failing here would break legit idle ticks on those versions.
    if (records.length === 0 && !X.hasCollection(body)) {
      onWarn?.(`${entity}: response had no COLLECTION node — treated as empty; first 200 chars: ${body.slice(0, 200)}`);
    }
    // A record with an unparseable AlterID must never advance the cursor —
    // that would silently skip data. Surface the raw shape instead.
    const invalid = records.find((r) => !Number.isFinite(r.alterId));
    if (invalid) {
      throw new TallyError(
        'TALLY_BAD_RESPONSE',
        `unparseable ALTERID; raw record: ${JSON.stringify(invalid.raw).slice(0, 300)}`,
      );
    }
    const page = records.slice(0, pageSize);
    return {
      records: page,
      hasMore: records.length > pageSize,
      maxAlterId: page.length ? page[page.length - 1].alterId : sinceAlterId,
    };
  }

  async importVoucher(company: string, cmd: X.VoucherCommand): Promise<X.ImportResult> {
    const body = await this.post(X.importVoucherEnvelope(company, cmd));
    const result = X.parseImportResult(body);
    if (result.errors > 0 || result.created + result.altered === 0) {
      throw new TallyError('TALLY_IMPORT_REJECTED', JSON.stringify(result));
    }
    return result;
  }

  /** Create or update a ledger master (categorization = PARENT group). */
  async importLedger(company: string, cmd: X.LedgerCommand): Promise<X.ImportResult> {
    const body = await this.post(X.importLedgerEnvelope(company, cmd));
    const result = X.parseImportResult(body);
    if (result.errors > 0 || result.created + result.altered === 0) {
      throw new TallyError('TALLY_IMPORT_REJECTED', JSON.stringify(result));
    }
    return result;
  }

  async existsLedgerByName(company: string, name: string): Promise<boolean> {
    const body = await this.post(X.ledgerByNameEnvelope(company, name));
    return X.parseLedgerFound(body);
  }

  /** Dedupe fallback when local imported_ids state is lost (§12: corrupt state). */
  async existsByExternalId(company: string, externalId: string): Promise<boolean> {
    const body = await this.post(X.findByExternalIdEnvelope(company, externalId));
    return X.parseFound(body);
  }
}

import type { Entity, Store } from '../store';
import { TallyAdapter, TallyError } from '../tally/adapter';
import { CloudClient, CloudError, backoffMs } from '../cloud/client';
import type { Logger } from '../logger';

export interface EngineOptions {
  companies: string[]; // '' means "currently open company"
  entities: Entity[];
  pageSize: number;
  maxPagesPerTick: number;
}

export interface TickReport {
  tallyUp: boolean;
  pushedRecords: number;
  queuedBatches: number;
  flushedBatches: number;
  imported: number;
  importFailed: number;
  errors: Record<string, number>;
}

/**
 * One tick = one bounded unit of both-direction sync. Correctness rules:
 *
 *  UP:   fetch (AlterID > cursor) page -> hand off to cloud (direct push OR
 *        durable outbox enqueue) -> only then advance cursor. Handoff and
 *        cursor advance are atomic in the failure path (Store.queueAndAdvance),
 *        so a crash can only ever cause a re-read of the same page, which the
 *        server's (guid, alter_id) idempotency absorbs.
 *
 *  DOWN: for each pending command: local dedupe -> Tally-side dedupe fallback
 *        -> import -> markImported BEFORE ack. Crash between import and ack
 *        redelivers the command; both dedupe layers turn it into 'duplicate'.
 */
export class SyncEngine {
  constructor(
    private tally: TallyAdapter,
    private cloud: CloudClient,
    private store: Store,
    private log: Logger,
    private opts: EngineOptions,
  ) {}

  async tick(): Promise<TickReport> {
    const report: TickReport = {
      tallyUp: false,
      pushedRecords: 0,
      queuedBatches: 0,
      flushedBatches: 0,
      imported: 0,
      importFailed: 0,
      errors: {},
    };

    try {
      report.tallyUp = await this.tally.ping();
    } catch (e) {
      this.count(report, 'TALLY_UNREACHABLE');
      this.log.debug('tally unreachable; idling this tick');
      // Still try to flush outbox — cloud may be reachable while Tally is closed.
      await this.flushOutbox(report);
      return report;
    }

    await this.flushOutbox(report);
    await this.upSync(report);
    await this.downSync(report);
    return report;
  }

  // ---------------- UP ----------------

  private async flushOutbox(report: TickReport) {
    for (;;) {
      const row = this.store.nextOutbox();
      if (!row) return;
      try {
        const batch = JSON.parse(row.payload);
        await this.cloud.pushBatch(row.entity, row.company, batch.records);
        this.store.completeOutbox(row.id);
        report.flushedBatches++;
      } catch (e: any) {
        if (e instanceof CloudError && !e.retryable) {
          // Poison batch (schema rejection). Park it out of the hot path but
          // never delete data: mark with a long retry and scream in telemetry.
          this.store.failOutbox(row.id, 24 * 3600 * 1000);
          this.count(report, 'OUTBOX_POISON');
          this.log.error('outbox batch rejected as non-retryable; parked 24h', { id: row.id });
        } else {
          this.store.failOutbox(row.id, backoffMs(row.attempts));
          this.count(report, 'CLOUD_UNREACHABLE');
        }
        return; // preserve FIFO; retry next tick
      }
    }
  }

  private async upSync(report: TickReport) {
    for (const company of this.companiesOrDefault()) {
      for (const entity of this.opts.entities) {
        let pages = 0;
        for (;;) {
          if (pages >= this.opts.maxPagesPerTick) break; // bound tick duration
          const cursor = this.store.getCursor(company, entity);
          let page;
          try {
            page = await this.tally.fetchChanged(entity, company, cursor, this.opts.pageSize);
          } catch (e: any) {
            this.count(report, e instanceof TallyError ? e.code : 'TALLY_BAD_RESPONSE');
            break;
          }
          if (page.records.length === 0) break;
          pages++;

          try {
            await this.cloud.pushBatch(entity, company, page.records);
            this.store.setCursor(company, entity, page.maxAlterId);
            report.pushedRecords += page.records.length;
          } catch (e: any) {
            // Durable handoff instead: outbox owns delivery from here.
            this.store.queueAndAdvance(company, entity, { records: page.records }, page.maxAlterId);
            report.queuedBatches++;
            this.count(report, 'CLOUD_UNREACHABLE');
          }
          if (!page.hasMore) break;
        }
      }
    }
  }

  // ---------------- DOWN ----------------

  private async downSync(report: TickReport) {
    let pending;
    try {
      pending = await this.cloud.fetchPending();
    } catch (e: any) {
      this.count(report, 'CLOUD_UNREACHABLE');
      return;
    }

    for (const cmd of pending) {
      try {
        if (this.store.hasImported(cmd.id)) {
          await this.cloud.ack(cmd.id, 'duplicate');
          continue;
        }

        if (cmd.kind === 'ledger') {
          // Natural-key dedupe/precondition: does the ledger exist by name?
          const exists = await this.tally.existsLedgerByName(cmd.company, cmd.name!);
          if (cmd.action === 'create' && exists) {
            this.store.markImported(cmd.id);
            await this.cloud.ack(cmd.id, 'duplicate', { reason: 'ledger already exists' });
            continue;
          }
          if (cmd.action === 'update' && !exists) {
            report.importFailed++;
            await this.cloud.ack(cmd.id, 'failed', { code: 'LEDGER_NOT_FOUND', name: cmd.name }).catch(() => {});
            continue;
          }
          const result = await this.tally.importLedger(cmd.company, cmd as any);
          this.store.markImported(cmd.id);
          await this.cloud.ack(cmd.id, 'imported', result);
          report.imported++;
          continue;
        }

        // voucher command (default kind)
        // Fallback dedupe against Tally itself — covers lost local state (§12).
        if (await this.tally.existsByExternalId(cmd.company, cmd.id)) {
          this.store.markImported(cmd.id);
          await this.cloud.ack(cmd.id, 'duplicate');
          continue;
        }
        const result = await this.tally.importVoucher(cmd.company, cmd as any);
        this.store.markImported(cmd.id, result.lastVchId);
        await this.cloud.ack(cmd.id, 'imported', result);
        report.imported++;
      } catch (e: any) {
        report.importFailed++;
        const code = e instanceof TallyError ? e.code : 'IMPORT_ERROR';
        this.count(report, code);
        // Ack failures so the server can park/retry with its own policy; if
        // the ack itself fails the command simply redelivers next tick.
        await this.cloud.ack(cmd.id, 'failed', { code, message: e?.message }).catch(() => {});
      }
    }
  }

  private companiesOrDefault(): string[] {
    return this.opts.companies.length ? this.opts.companies : [''];
  }

  private count(report: TickReport, code: string) {
    report.errors[code] = (report.errors[code] ?? 0) + 1;
  }
}

# Connector Gateway API Reference

The HTTP contract between the connector and its backend. `gateway-lite` (`npm run gateway`) implements all of it locally; the production cloud gateway must implement at least the four `/v1/connector/*` endpoints identically. Every curl below was executed against a running gateway-lite and shows the actual response.

Base URL below: `http://127.0.0.1:8080`. Auth: the connector sends `Authorization: Bearer <DEVICE_TOKEN>`; gateway-lite accepts any value (production validates it). All bodies are JSON. Windows note: use `curl.exe` in PowerShell (plain `curl` aliases to Invoke-WebRequest), or the PowerShell equivalents at the end.

---

## Sync APIs (called by the connector)

### POST /v1/connector/{entity}/batch — up-sync ingest

`{entity}` ∈ `vouchers | ledgers | stockitems`. The connector POSTs one page (≤500 records) per call. **Idempotent** on `(company, guid, alterId)` — first write wins; replaying a batch stores nothing new, which is what makes the connector's at-least-once delivery safe.

Request:
```json
{
  "company": "Acme Industries",
  "records": [
    {
      "guid": "g-100",
      "masterId": "11",
      "alterId": 57,
      "raw": {
        "DATE": "20260729",
        "VOUCHERTYPENAME": "Sales",
        "VOUCHERNUMBER": "S-42",
        "PARTYLEDGERNAME": "Wayne Traders",
        "AMOUNT": "12500.00",
        "NARRATION": "bulk order"
      }
    }
  ]
}
```

```bash
curl -X POST http://127.0.0.1:8080/v1/connector/vouchers/batch \
  -H "Content-Type: application/json" \
  -d '{"company":"Acme Industries","records":[{"guid":"g-100","alterId":57,"raw":{"DATE":"20260729","VOUCHERTYPENAME":"Sales","VOUCHERNUMBER":"S-42","PARTYLEDGERNAME":"Wayne Traders","AMOUNT":"12500.00","NARRATION":"bulk order"}}]}'
```
Response: `{"stored":1,"total":1}` — replay the identical call and you get `{"stored":0,"total":1}`.

Errors: `400` malformed JSON (the connector treats 4xx as a poison batch and parks it), `5xx`/network (the connector retries with backoff).

### GET /v1/connector/pending — commands awaiting import into Tally

```bash
curl http://127.0.0.1:8080/v1/connector/pending
```
Response:
```json
{"items":[{"id":"cmd-311e29d6","company":"","date":"20260729","voucherType":"Receipt",
  "number":"R-9","narration":"payment received",
  "entries":[{"ledger":"Wayne Traders","amount":-5000},{"ledger":"HDFC Bank","amount":5000}]}]}
```
Items are re-delivered every poll until acked `imported` or `duplicate` — the connector's dedupe makes re-delivery harmless.

### POST /v1/connector/pending/{id}/ack — command outcome

`status` ∈ `imported | duplicate | failed`. `imported`/`duplicate` remove the command from the queue; `failed` keeps the ack on record for review (production may retry with its own policy).

```bash
curl -X POST http://127.0.0.1:8080/v1/connector/pending/cmd-311e29d6/ack \
  -H "Content-Type: application/json" \
  -d '{"status":"imported","detail":{"created":1,"lastVchId":"3021"}}'
```
Response: `{}`

### POST /v1/connector/heartbeat — health in, config out

```bash
curl -X POST http://127.0.0.1:8080/v1/connector/heartbeat \
  -H "Content-Type: application/json" \
  -d '{"version":"1.0.0-alpha.1","tallyUp":true,"outboxDepth":0,"cursors":{},"errors":{}}'
```
Response: `{"config":{}}` — a non-empty `config` (e.g. `{"pollIntervalMs":10000,"logLevel":"debug"}`) is applied by the connector immediately.

---

## Lightweight APIs (for you / other services)

### GET /entries — browse everything ingested

Optional filters: `?type=Sales` (voucher type or entity), `?party=Wayne` (substring match on party ledger). Combine freely.

```bash
curl "http://127.0.0.1:8080/entries?party=Wayne"
```
Response:
```json
{"count":1,"entries":[{"entity":"vouchers","company":"Acme Industries","guid":"g-100",
  "alterId":57,"raw":{"DATE":"20260729","VOUCHERTYPENAME":"Sales","VOUCHERNUMBER":"S-42",
  "PARTYLEDGERNAME":"Wayne Traders","AMOUNT":"12500.00","NARRATION":"bulk order"},
  "receivedAt":"2026-07-29T11:26:31.402Z"}]}
```

### POST /commands — queue a voucher for down-sync into Tally

The gateway validates that `entries` amounts balance to zero (double-entry) before queueing. The connector picks it up on its next tick, imports it into Tally, and acks. Negative amount = debit leg, positive = credit leg; both ledgers must exist in the open Tally company or the import is acked `failed`.

```bash
curl -X POST http://127.0.0.1:8080/commands \
  -H "Content-Type: application/json" \
  -d '{"date":"20260729","voucherType":"Receipt","number":"R-9","narration":"payment received","entries":[{"ledger":"Wayne Traders","amount":-5000},{"ledger":"HDFC Bank","amount":5000}]}'
```
Response: `{"id":"cmd-311e29d6","queued":1}`

Unbalanced request → `400 {"error":"entries must balance to 0 (got 100)"}`

### GET /status — gateway health and recent activity

```bash
curl http://127.0.0.1:8080/status
```
Response:
```json
{"entries":1,"pending":1,
 "acks":[{"id":"cmd-311e29d6","status":"imported","at":"2026-07-29T11:27:03.114Z"}],
 "lastHeartbeat":{"version":"1.0.0-alpha.1","tallyUp":true,"outboxDepth":0,"at":"..."}}
```

---

## The full loop as curls

With Tally open and the connector + gateway running, this sequence demonstrates both directions end to end:

```bash
# 1. queue a payment into Tally
curl -X POST http://127.0.0.1:8080/commands -H "Content-Type: application/json" \
  -d '{"date":"20260729","voucherType":"Receipt","entries":[{"ledger":"Cash","amount":-100},{"ledger":"Sales","amount":100}]}'

# 2. within one poll interval, confirm it was imported
curl http://127.0.0.1:8080/status          # acks shows status: imported

# 3. the voucher the connector just created echoes back up — see it arrive
curl "http://127.0.0.1:8080/entries?type=Receipt"
```

## PowerShell equivalents (Windows)

```powershell
# batch ingest
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8080/v1/connector/vouchers/batch `
  -ContentType 'application/json' `
  -Body '{"company":"Acme","records":[{"guid":"g-1","alterId":5,"raw":{"VOUCHERTYPENAME":"Sales"}}]}'

# queue a command
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8080/commands `
  -ContentType 'application/json' `
  -Body '{"date":"20260729","voucherType":"Receipt","entries":[{"ledger":"Cash","amount":-100},{"ledger":"Sales","amount":100}]}'

# browse / status
Invoke-RestMethod http://127.0.0.1:8080/entries
Invoke-RestMethod http://127.0.0.1:8080/status
```

# How the Tally Connector Works — Workflow Documentation

This document explains every logical workflow inside the connector, in plain language but in full detail. It's written so that someone who has never seen the code can understand exactly what happens, when, and why — and so that someone debugging at 2 AM can find the failure story that matches what they're seeing. Code references point at files in this repo.

---

## 1. The big picture

The connector is a small program that lives on the same Windows PC as Tally. Its whole job is to be a reliable courier between two parties that can't talk to each other directly:

- **Tally**, which only speaks XML over HTTP on `localhost:9000`, only while it's open, and has no memory of what it already told you.
- **The gateway API** (the cloud, or `gateway-lite` locally), which lives across an unreliable network.

The courier's promise is simple to state and hard to keep: **every change in Tally reaches the gateway exactly once, and every command from the gateway lands in Tally exactly once — no matter what crashes, restarts, or goes offline in between.** Everything in this document is in service of that promise.

Three files carry the promise: `src/sync/engine.ts` (the decisions), `src/store.ts` (the memory), `src/tally/xml.ts` (the translation). Everything else is plumbing around them.

---

## 2. What the connector remembers (the local database)

All durable state lives in one SQLite file, `connector.db` (in `%APPDATA%` when installed). Four tables:

**`cursors`** — one row per (company, entity). Stores the highest Tally `AlterID` that has been *safely handed off*. This is the bookmark; everything about incremental sync reduces to "what's my cursor?"

**`outbox`** — batches of records that were read from Tally but couldn't be delivered to the gateway. Each row: the JSON payload, an attempt counter, and a next-retry timestamp. This table is why going offline loses nothing.

**`imported_ids`** — every external (cloud) ID the connector has ever written into Tally. This is the first line of defence against importing the same command twice.

**`kv`** — misc key-values.

Why SQLite and not a JSON file: transactions. Several workflows below need two changes to happen *together or not at all* (e.g. "save this batch to the outbox AND move the cursor"). SQLite's `BEGIN IMMEDIATE … COMMIT` gives us that; a JSON file can be half-written when the power goes.

The database uses Node's built-in `node:sqlite`, so there are zero native dependencies — nothing to compile on any machine.

---

## 3. The heartbeat of everything: the tick

The connector does all of its work in a **tick** — one bounded unit of syncing, run every `POLL_INTERVAL_MS` (default 20 s). Ticks are strictly serialized: if one is still running, the next is postponed, never overlapped. `src/service.ts` owns the schedule; `engine.tick()` does the work.

Each tick executes exactly four phases, in this order:

```
1. PING       is Tally answering?
2. FLUSH      retry anything stuck in the outbox
3. UP-SYNC    Tally → gateway (new/changed records)
4. DOWN-SYNC  gateway → Tally (commands to import)
```

Two subtleties in the ordering:

- **Flush runs even when Tally is down.** Tally being closed says nothing about the internet. If the accountant shut Tally but the outbox holds yesterday's batches, this tick still delivers them.
- **Ping failure is not an error.** Tally closed is a *normal state* for this system — merchants shut it every evening. The tick logs it at debug level, reports `tally_down` in the heartbeat, and waits.

A tick never throws to the outside; every phase catches and counts its own errors into a `TickReport` (which feeds the status window and the heartbeat).

---

## 4. Up-sync in depth: Tally → gateway

### 4.1 How the connector knows what changed

Tally maintains one company-wide counter, the **AlterID**, that ticks up on every create or modify. Every voucher and master carries the AlterID from its own last change. So the question "what changed since I last looked?" becomes a single filter: *give me everything with AlterID greater than my cursor.*

The connector sends that filter as an **inline TDL collection** — a query definition embedded in the HTTP request itself (`fetchChangedEnvelope` in `src/tally/xml.ts`). Nothing is ever installed inside the merchant's Tally; each request carries its own definition.

Notice what this design gives for free:

- **Edits are captured.** An edited voucher gets a fresh AlterID, so it reappears above the cursor as a new "version" of the same GUID. The gateway stores both versions (keyed on `guid + alterId`).
- **The very first sync is just a special case.** A new install has cursor 0, so "everything above 0" = the entire company history. Backfill isn't separate code; it's the normal loop starting from zero.

And what it doesn't give: **deletions**. A deleted voucher simply vanishes — no tombstone appears above any cursor. Detecting deletions requires a separate reconciliation sweep (compare full GUID lists periodically); that's a planned Phase 2 job, not part of the tick.

### 4.2 The page loop

Within one tick, per company, per entity (vouchers, ledgers, stock items), the engine loops:

1. Read the cursor from SQLite.
2. Ask Tally for changes above it. Sort ascending by AlterID, take the first `PAGE_SIZE` (500).
3. Hand the page to the gateway (see 4.3).
4. On successful handoff, write the new cursor = the highest AlterID in the page.
5. If Tally said there's more, go again — up to `maxPagesPerTick` (20), so one giant backfill can't make a tick run forever. Whatever's left is picked up next tick, because the cursor now points at where we stopped.

A parsing safety rule sits inside step 2: real Tally sometimes returns fields as attributed XML elements (`<ALTERID TYPE="Number"> 1,204</ALTERID>` — an object with spaces and comma grouping once parsed). The XML layer coerces all known shapes; if an AlterID *still* can't be parsed to a number, the adapter **refuses the whole page** rather than guessing. A wrong cursor silently skips data forever; a refused page just retries next tick and screams in the logs with the raw record attached. Fail loud beats fail wrong.

### 4.3 The handoff: direct push or outbox

Step 3 has two outcomes:

**Gateway reachable →** POST the page to `/v1/connector/{entity}/batch`, then advance the cursor. Done.

**Gateway unreachable →** this is the interesting one. In a *single SQLite transaction* (`Store.queueAndAdvance`), the engine writes the batch into the `outbox` table *and* advances the cursor. From that instant, responsibility for delivery transfers from Tally to the outbox: Tally will never be asked for those records again, and the outbox will retry them until the gateway accepts.

Why advance the cursor on failure? Because the alternative — leave the cursor, re-read the same records from Tally next tick — means the connector makes no forward progress while offline, and the re-reads grow unbounded. Instead, "read from Tally" and "deliver to gateway" are decoupled; the outbox is the buffer between them. The transaction is what makes this crash-safe: there is no instant where the batch is dropped from Tally's view but not yet in the outbox.

**"Pending upload batches" in the status window is precisely the number of rows in this outbox table.** A rising number means the connector is reading Tally fine but can't reach the gateway — data is banked locally, not lost.

### 4.4 Outbox flushing, backoff, and poison batches

At the start of every tick, the engine drains the outbox oldest-first (FIFO — order is preserved). Each batch:

- **Delivered →** deleted from the outbox.
- **Failed with a network error or 5xx →** attempt counter incremented, next-retry set by exponential backoff with jitter (2 s doubling up to a 5-minute cap). The flush loop stops at the first failure to preserve ordering; it all retries next tick.
- **Rejected with a 4xx (other than auth) →** this batch is *poison*: the gateway is telling us the payload itself is bad, and hot-retrying it forever would block everything behind it. The batch is parked for 24 hours (never deleted — deleting merchant data is not an option), an `OUTBOX_POISON` error is counted into telemetry, and *fresh data keeps flowing past it*. A human investigates via the dashboard/logs.

### 4.5 Why re-sends are harmless: idempotency

At-least-once delivery means the gateway can receive the same record twice — e.g. the connector crashes after the POST succeeds but before the cursor write lands, and the next tick re-reads the page. The gateway makes this a non-event by deduplicating on the compound key **(company, guid, alterId)**: replaying a batch stores nothing new. The chaos test "crash after cloud push but before cursor write" proves this end to end. Exactly-once, as always, is really *at-least-once transport + idempotent receiver*.

---

## 5. Down-sync in depth: gateway → Tally

The gateway keeps a queue of **commands** — vouchers the platform wants written into Tally (a payment received, an invoice raised). Every tick, the connector fetches `GET /v1/connector/pending` and processes each command through a strict sequence:

```
1. Have I imported this ID before?        (local imported_ids table)
     yes → ack 'duplicate', stop.
2. Does Tally already contain this ID?    (query for the [ext:<id>] tag / UDF)
     yes → record it locally, ack 'duplicate', stop.
3. Import the voucher into Tally.
     Tally rejected it → ack 'failed' with the reason, stop.
4. Record the ID in imported_ids.         (BEFORE acking — order matters)
5. Ack 'imported'.
```

Why **two** dedupe layers? Each covers the other's blind spot:

- The local table is fast but lives on a merchant PC — it can be deleted, corrupted, or lost with the machine. If it's gone, layer 2 asks Tally itself: every voucher the connector creates is stamped with the command's external ID (in a UDF, mirrored in the narration as `[ext:<id>]`), and a TDL filter can find it. The chaos test "lost local state" wipes the database and proves the command still isn't imported twice.
- Conversely, querying Tally for every command is slower, so the local table short-circuits the common case.

Why record locally *before* acking (step 4 before 5)? Consider the crash window between them: the import succeeded, the ack never went out, so the gateway re-delivers the command next tick. Because the local record was written first, step 1 catches it → `duplicate`. If the order were reversed, that crash window would produce a double import — the one unforgivable outcome for accounting data.

Failed imports don't block the queue: each command is processed independently, a Tally rejection is acked `failed(reason)` so the server can park it for human review, and the loop moves on to the next command.

**The echo problem:** a voucher the connector writes into Tally gets its own AlterID, so up-sync will dutifully carry it back to the gateway. That's not a bug — the external-ID stamp travels with it, so the gateway can recognise "this change originated from me" and treat it as confirmation rather than as a new merchant edit.

---

## 6. The supporting workflows

### 6.1 Heartbeat and remote config
After every tick, the service POSTs a heartbeat: connector version, whether Tally was up, outbox depth, and the tick's error counters. The response can carry **config overrides** (poll interval, page size, log level) which take effect immediately — the fleet can be tuned from the server without shipping an update. Heartbeat failures are swallowed; telemetry must never break syncing.

### 6.2 The hint listener (push-assist)
Polling means up to 20 s of lag. Tally can do better: with the optional TDL add-on loaded (`tdl/tally-connector-hint.tdl`), Tally itself fires an HTTP POST to the connector (`127.0.0.1:9797`) the moment an accountant saves a voucher. The connector's handler does exactly two things, in this order: **respond `<STATUS>1</STATUS>` immediately and unconditionally**, then pull the next tick forward to ~250 ms (debouncing bursts of saves into one tick).

The order is a safety contract, not a style choice: Tally refuses to accept the form until it sees STATUS 1, so any computation before responding would let our software freeze data entry. The hint carries no data and triggers nothing directly — it only moves the next poll earlier. A lost hint therefore loses nothing; the cursor mechanism remains the sole source of truth. Push is an accelerator, never the data path.

### 6.3 Company awareness
When Tally is reachable, the service fetches the list of loaded companies (name, GUID, books-from date) — on first contact and every ~15 ticks after. The status window shows it; the company **GUID** is also the key the gateway uses to scope everything (cursors, idempotency) when multi-company support lands.

### 6.4 The Electron shell
The sync engine runs in Electron's **main process** — it needs no window to keep working. The tray icon offers Status / Sync now / Quit; the status window is a dumb panel polling `getStatus()` over IPC every 3 s (connection state, companies, last tick, outbox depth, recent logs). Closing the window does not stop syncing; quitting from the tray does, after a clean `stop()`.

### 6.5 The doctor
`npm run doctor` tests each leg of the pipeline *in isolation* and names the broken one: local SQLite writability → Tally ping (with the exact Tally settings to check on failure) → a real voucher query (printing the first raw record, so field-shape drift across Tally versions is visible immediately) → gateway reachability and auth → hint port. When "sync doesn't work," this turns guessing into reading.

### 6.6 gateway-lite
`npm run gateway` starts a single-file backend implementing the full production contract (idempotent batch ingest, pending/ack, heartbeat) **plus** two lightweight endpoints folded in from the tally-lite demo: `GET /entries` to browse everything ingested (filterable by type/party) and `POST /commands` to enqueue a voucher for down-sync (validated: entries must balance to zero). State persists to one JSON file. It exists so the connector can run *for real* — full loop, both directions — before the production cloud gateway is built, and it doubles as the executable specification of what that gateway must implement.

---

## 7. Failure stories, end to end

Each of these is a chaos test in `test/engine.test.ts` — not a hope, a proof.

**The internet dies mid-day.** Ticks keep reading new vouchers from Tally; every batch lands in the outbox; the cursor keeps advancing; "pending upload batches" climbs. Hours later the network returns: the next tick's flush phase delivers everything oldest-first, the counter drains to zero, the gateway's idempotency absorbs any overlap. Nothing lost, nothing duplicated, nobody had to do anything.

**The PC bluescreens mid-sync.** Whatever transaction was in flight either committed fully or not at all — that's SQLite's job. On reboot the connector resumes from the persisted cursor. Worst case it re-reads or re-sends one page; the (guid, alterId) key makes the replay invisible.

**Tally rejects an import** (unknown ledger, closed period). The command is acked `failed` with Tally's reason, the server parks it for a human, and every other command still processes this same tick.

**The gateway rejects a batch as malformed.** Poison handling: parked 24 h, alarmed, never deleted, fresh data flows past it.

**Someone deletes `connector.db`.** Cursors reset to 0 → Tally history re-streams → gateway dedupes it all (safe, just traffic). Down-sync dedupe survives via the Tally-side external-ID lookup. The system heals from total local amnesia.

**Tally returns a field shape we've never seen.** The adapter refuses the page with the raw record in the error rather than corrupting the cursor. The record becomes a golden fixture and a coercion fix — which is exactly how the `<ALTERID TYPE="Number">` production crash was closed.

---

## 8. Glossary

- **AlterID** — Tally's company-wide change counter; stamped on every record at its last modification.
- **Cursor** — the highest AlterID the connector has durably handed off, per company per entity.
- **Tick** — one bounded run of ping → flush → up-sync → down-sync.
- **Outbox** — SQLite-persisted queue of batches awaiting gateway delivery; "pending upload batches" in the UI.
- **Poison batch** — a batch the gateway rejects as malformed (4xx); parked, never deleted.
- **Backoff with jitter** — retry delays that double (2 s → 5 min cap) with randomness so a fleet doesn't stampede a recovering server.
- **Idempotency key** — (company, guid, alterId) up-sync; external command ID down-sync. What turns at-least-once into effectively exactly-once.
- **External ID / [ext:...]** — the cloud command's ID stamped into every voucher the connector creates; enables Tally-side dedupe and echo recognition.
- **Hint** — a data-free POST from Tally's TDL add-on that pulls the next poll forward.
- **Golden fixture** — a captured real Tally response checked into `fixtures/` and locked in by tests.

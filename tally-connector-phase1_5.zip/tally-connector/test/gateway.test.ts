import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TallySimulator } from '../simulator/tallySim';
import { LiteGateway } from '../src/gateway-lite';
import { Store } from '../src/store';
import { TallyAdapter } from '../src/tally/adapter';
import { CloudClient } from '../src/cloud/client';
import { SyncEngine } from '../src/sync/engine';
import { Logger } from '../src/logger';

let tally: TallySimulator;
let gw: LiteGateway;
let tallyPort: number;
let gwPort: number;
let dir: string;

beforeEach(async () => {
  tally = new TallySimulator();
  gw = new LiteGateway(); // no persistence in tests
  tallyPort = await tally.listen();
  gwPort = await gw.listen();
  dir = mkdtempSync(join(tmpdir(), 'gwlite-'));
});

afterEach(() => {
  tally.close();
  gw.close();
  rmSync(dir, { recursive: true, force: true });
});

function makeEngine() {
  const store = new Store(join(dir, 'e.db'));
  const engine = new SyncEngine(
    new TallyAdapter({ url: `http://127.0.0.1:${tallyPort}`, timeoutMs: 400 }),
    new CloudClient(`http://127.0.0.1:${gwPort}`, 'dev', fetch, 400),
    store,
    new Logger('error', 100, () => {}),
    { companies: [''], entities: ['vouchers'], pageSize: 100, maxPagesPerTick: 5 },
  );
  return { store, engine };
}

describe('production engine against gateway-lite', () => {
  it('full loop: up-sync ingests idempotently, command round-trips into Tally', async () => {
    tally.addVoucher();
    tally.addVoucher();
    const cmdId = gw.seedCommand({
      date: '20260729',
      voucherType: 'Receipt',
      number: 'R-1',
      narration: 'from lite gateway',
      entries: [
        { ledger: 'Cash', amount: -500 },
        { ledger: 'Sales', amount: 500 },
      ],
    });

    const { store, engine } = makeEngine();
    await engine.tick();

    expect(gw.entryCount()).toBe(2); // both vouchers ingested
    expect(tally.importedExternalIds).toContain(cmdId); // command written into Tally

    // Re-tick: idempotent (cursor holds; command acked away)
    await engine.tick();
    expect(gw.entryCount()).toBeGreaterThanOrEqual(2);
    expect(tally.importedExternalIds.filter((x) => x === cmdId)).toHaveLength(1);
    store.close();
  });

  it('lightweight extras: /entries browse and /commands validation', async () => {
    tally.addVoucher({ VOUCHERTYPENAME: 'Sales', PARTYLEDGERNAME: 'Acme Traders' });
    const { store, engine } = makeEngine();
    await engine.tick();

    const browse = await (await fetch(`http://127.0.0.1:${gwPort}/entries?party=Acme`)).json();
    expect(browse.count).toBe(1);

    const bad = await fetch(`http://127.0.0.1:${gwPort}/commands`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ date: '20260729', voucherType: 'Receipt', entries: [{ ledger: 'Cash', amount: 100 }] }),
    });
    expect(bad.status).toBe(400); // unbalanced entries rejected

    const good = await fetch(`http://127.0.0.1:${gwPort}/commands`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        date: '20260729',
        voucherType: 'Receipt',
        entries: [
          { ledger: 'Cash', amount: -100 },
          { ledger: 'Sales', amount: 100 },
        ],
      }),
    });
    expect(good.status).toBe(200);
    const { id } = await good.json();

    await engine.tick(); // connector picks it up and imports
    expect(tally.importedExternalIds).toContain(id);

    const status = await (await fetch(`http://127.0.0.1:${gwPort}/status`)).json();
    expect(status.pending).toBe(0);
    expect(status.acks.some((a: any) => a.id === id && a.status === 'imported')).toBe(true);
    store.close();
  });
});

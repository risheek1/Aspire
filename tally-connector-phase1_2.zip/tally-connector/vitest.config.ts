import { defineConfig } from 'vitest/config';

// node:sqlite is a recent core module; Vite's builtin list may not include it
// yet, so mark all node: specifiers external explicitly.
export default defineConfig({
  ssr: { external: true },
  test: {
    server: { deps: { external: [/^node:/] } },
  },
});

/**
 * Electron shell for the Tally connector (spec §5.5 tray UI + §10 packaging).
 *
 * The sync engine runs IN THE MAIN PROCESS (full Node access, node:sqlite,
 * survives with no window open). The renderer is a dumb status panel fed over
 * IPC. Requires Electron >= 35 (bundles Node 22.14+, where node:sqlite is
 * available without flags).
 */
const { app, Tray, Menu, BrowserWindow, ipcMain, nativeImage } = require('electron');
const path = require('node:path');

// Single instance — a second launch just pings the first.
if (!app.requestSingleInstanceLock()) app.quit();

let svc = null;
let tray = null;
let statusWin = null;

function startService() {
  // Persist DB + token under the per-user app data dir, not the install dir
  // (install dir is not writable under Program Files).
  process.env.DB_PATH = process.env.DB_PATH || path.join(app.getPath('userData'), 'connector.db');
  const { ConnectorService } = require('../dist/src/service');
  svc = new ConnectorService();
  svc.start();
}

function openStatusWindow() {
  if (statusWin) return statusWin.focus();
  statusWin = new BrowserWindow({
    width: 420,
    height: 560,
    resizable: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'app-icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js') },
  });
  statusWin.loadFile(path.join(__dirname, 'status.html'));
  statusWin.on('closed', () => (statusWin = null));
}

function buildTray() {
  const icon = nativeImage
    .createFromPath(path.join(__dirname, 'assets', 'tray-icon.png'))
    .resize({ width: 16, height: 16 });
  tray = new Tray(icon);
  tray.setToolTip('Razorpay Tally Connector');
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: 'Status', click: openStatusWindow },
      { label: 'Sync now', click: () => svc?.syncNow() },
      { type: 'separator' },
      { label: 'Quit', click: () => app.quit() },
    ]),
  );
  tray.on('double-click', openStatusWindow);
}

app.whenReady().then(() => {
  startService();
  buildTray();
  // Start on login (merchant expectation: install once, forget).
  if (app.isPackaged) app.setLoginItemSettings({ openAtLogin: true });
});

// Tray app: closing the status window must NOT quit the sync engine.
app.on('window-all-closed', (e) => e?.preventDefault?.());

app.on('second-instance', openStatusWindow);

app.on('before-quit', async () => {
  await svc?.stop();
});

ipcMain.handle('connector:status', () => svc?.getStatus() ?? null);
ipcMain.handle('connector:syncNow', () => svc?.syncNow());

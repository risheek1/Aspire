const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('connector', {
  status: () => ipcRenderer.invoke('connector:status'),
  syncNow: () => ipcRenderer.invoke('connector:syncNow'),
});

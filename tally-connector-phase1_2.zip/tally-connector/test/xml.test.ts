import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import * as X from '../src/tally/xml';

const fx = (name: string) => readFileSync(join(__dirname, '..', 'fixtures', name), 'utf8');

describe('golden: parseChanged', () => {
  it('parses multi-voucher responses and sorts ascending by alterId', () => {
    const recs = X.parseChanged('vouchers', fx('changed_vouchers_multi.xml'));
    expect(recs).toHaveLength(2);
    expect(recs.map((r) => r.alterId)).toEqual([99, 101]); // sorted, not doc order
    expect(recs[1].guid).toBe('g-1');
    expect(recs[1].raw.PARTYLEDGERNAME).toBe('Acme');
  });

  it('handles the single-element case (Tally returns object, not array)', () => {
    const recs = X.parseChanged('vouchers', fx('changed_vouchers_single.xml'));
    expect(recs).toHaveLength(1);
    expect(recs[0].guid).toBe('g-solo');
    expect(recs[0].alterId).toBe(42);
  });

  it('returns empty for empty collections', () => {
    const recs = X.parseChanged(
      'vouchers',
      '<ENVELOPE><BODY><DATA><COLLECTION></COLLECTION></DATA></BODY></ENVELOPE>',
    );
    expect(recs).toEqual([]);
  });
});

describe('golden: import results', () => {
  it('parses success with LASTVCHID', () => {
    const r = X.parseImportResult(fx('import_success.xml'));
    expect(r).toEqual({ created: 1, altered: 0, errors: 0, lastVchId: '3021' });
  });
  it('parses rejection', () => {
    const r = X.parseImportResult(fx('import_rejected.xml'));
    expect(r.errors).toBe(1);
    expect(r.created).toBe(0);
  });
});

describe('envelope builders', () => {
  it('embeds the AlterID filter and entity fetch list', () => {
    const env = X.fetchChangedEnvelope('vouchers', 'My Co', 12345);
    expect(env).toContain('$AlterID &gt; 12345');
    expect(env).toContain('<SVCURRENTCOMPANY>My Co</SVCURRENTCOMPANY>');
    expect(env).toContain('ALTERID, MASTERID');
  });

  it('escapes XML-hostile input everywhere user data lands', () => {
    const env = X.importVoucherEnvelope('A & B "Co"', {
      id: 'x</NARRATION><HACK>',
      date: '20260729',
      voucherType: 'Sales',
      narration: '<script>',
      entries: [{ ledger: 'L & M', amount: 10 }],
    });
    expect(env).not.toContain('<HACK>');
    expect(env).toContain('&lt;script&gt;');
    expect(env).toContain('L &amp; M');
    expect(env).toContain('A &amp; B &quot;Co&quot;');
  });

  it('sets debit/credit convention from amount sign', () => {
    const env = X.importVoucherEnvelope('', {
      id: '1',
      date: '20260729',
      voucherType: 'Receipt',
      entries: [
        { ledger: 'Party', amount: -500 },
        { ledger: 'Bank', amount: 500 },
      ],
    });
    expect(env).toContain('<ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>');
    expect(env).toContain('<ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>');
  });
});

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { TallySimulator } from '../simulator/tallySim';
import { CloudSimulator } from '../simulator/cloudSim';
import { Store } from '../src/store';
import { TallyAdapter } from '../src/tally/adapter';
import { CloudClient } from '../src/cloud/client';
import { SyncEngine } from '../src/sync/engine';
import { Logger } from '../src/logger';

let tally: TallySimulator;
let cloud: CloudSimulator;
let tallyPort: number;
let cloudPort: number;
let dir: string;

function makeEngine(dbPath: string) {
  const store = new Store(dbPath);
  const engine = new SyncEngine(
    new TallyAdapter({ url: `http://127.0.0.1:${tallyPort}`, timeoutMs: 400 }),
    new CloudClient(`http://127.0.0.1:${cloudPort}`, 'test-token', fetch, 400),
    store,
    new Logger('error', 100, () => {}),
    { companies: [''], entities: ['vouchers'], pageSize: 3, maxPagesPerTick: 10 },
  );
  return { store, engine };
}

beforeEach(async () => {
  tally = new TallySimulator();
  cloud = new CloudSimulator();
  tallyPort = await tally.listen();
  cloudPort = await cloud.listen();
  dir = mkdtempSync(join(tmpdir(), 'conn-'));
});

afterEach(() => {
  tally.close();
  cloud.close();
  rmSync(dir, { recursive: true, force: true });
});

describe('up-sync', () => {
  it('pushes new vouchers once and advances the cursor', async () => {
    tally.addVoucher();
    tally.addVoucher();
    const { store, engine } = makeEngine(join(dir, 'a.db'));

    await engine.tick();
    expect(cloud.uniqueRecords()).toHaveLength(2);
    expect(store.getCursor('', 'vouchers')).toBe(2);

    // Idle tick: nothing new, nothing re-sent.
    const calls = cloud.pushCalls;
    await engine.tick();
    expect(cloud.pushCalls).toBe(calls);
    store.close();
  });

  it('pages large deltas within one tick (pageSize=3)', async () => {
    for (let i = 0; i < 8; i++) tally.addVoucher();
    const { store, engine } = makeEngine(join(dir, 'b.db'));
    await engine.tick();
    expect(cloud.uniqueRecords()).toHaveLength(8);
    expect(store.getCursor('', 'vouchers')).toBe(8);
    store.close();
  });

  it('captures edits (same GUID, new ALTERID) as new deltas', async () => {
    const v = tally.addVoucher({ GUID: 'g-edit' });
    const { store, engine } = makeEngine(join(dir, 'c.db'));
    await engine.tick();

    tally.addVoucher({ GUID: 'g-edit', AMOUNT: 9999 }); // merchant edits it
    await engine.tick();

    const versions = cloud.uniqueRecords().filter((r) => r.guid === 'g-edit');
    expect(versions).toHaveLength(2); // both alterId versions ingested
    expect(versions.map((r) => r.alterId).sort()).toEqual([v.ALTERID, v.ALTERID + 1]);
    store.close();
  });

  it('CHAOS: cloud outage -> outbox holds data -> flush on recovery, zero loss/dupes', async () => {
    tally.addVoucher();
    tally.addVoucher();
    cloud.fault = 'http_500';
    const { store, engine } = makeEngine(join(dir, 'd.db'));

    await engine.tick();
    expect(cloud.uniqueRecords()).toHaveLength(0);
    expect(store.outboxDepth()).toBeGreaterThan(0);
    expect(store.getCursor('', 'vouchers')).toBe(2); // cursor advanced with the queue

    // More activity while offline
    tally.addVoucher();
    await engine.tick();

    cloud.fault = 'none';
    // Outbox rows back off; force them due for the test.
    // (Two ticks: flush queued batches, then normal empty pass.)
    await new Promise((r) => setTimeout(r, 10));
    (store as any)['db'].prepare('UPDATE outbox SET next_retry_at=0').run();
    await engine.tick();

    expect(cloud.uniqueRecords()).toHaveLength(3);
    expect(store.outboxDepth()).toBe(0);
    store.close();
  });

  it('CHAOS: crash after cloud push but before cursor write -> replay absorbed by idempotency', async () => {
    tally.addVoucher();
    const { store, engine } = makeEngine(join(dir, 'e.db'));
    await engine.tick();

    // Simulate the crash by rolling the cursor back (same effect: page re-read).
    store.setCursor('', 'vouchers', 0);
    await engine.tick();

    expect(cloud.uniqueRecords()).toHaveLength(1); // dedupe on (guid, alterId)
    store.close();
  });

  it('CHAOS: Tally down mid-run -> engine idles and recovers, still flushes outbox', async () => {
    tally.addVoucher();
    cloud.fault = 'http_500';
    const { store, engine } = makeEngine(join(dir, 'f.db'));
    await engine.tick(); // queued to outbox

    tally.fault = 'down';
    cloud.fault = 'none';
    (store as any)['db'].prepare('UPDATE outbox SET next_retry_at=0').run();
    const r = await engine.tick(); // Tally unreachable, but outbox still flushes
    expect(r.tallyUp).toBe(false);
    expect(cloud.uniqueRecords()).toHaveLength(1);

    tally.fault = 'none';
    tally.addVoucher();
    await engine.tick();
    expect(cloud.uniqueRecords()).toHaveLength(2);
    store.close();
  });

  it('CHAOS: malformed Tally XML does not advance the cursor or lose data', async () => {
    tally.addVoucher();
    tally.fault = 'malformed';
    const { store, engine } = makeEngine(join(dir, 'g.db'));
    const r = await engine.tick();
    expect(store.getCursor('', 'vouchers')).toBe(0);
    expect(r.errors['TALLY_BAD_RESPONSE']).toBeGreaterThan(0);

    tally.fault = 'none';
    await engine.tick();
    expect(cloud.uniqueRecords()).toHaveLength(1);
    store.close();
  });

  it('poison batch (400) is parked, does not block later data', async () => {
    tally.addVoucher();
    cloud.fault = 'http_500';
    const { store, engine } = makeEngine(join(dir, 'h.db'));
    await engine.tick(); // -> outbox

    cloud.fault = 'reject_400';
    (store as any)['db'].prepare('UPDATE outbox SET next_retry_at=0').run();
    const r = await engine.tick();
    expect(r.errors['OUTBOX_POISON']).toBe(1);
    expect(store.outboxDepth()).toBe(1); // parked, not deleted

    cloud.fault = 'none';
    tally.addVoucher();
    await engine.tick(); // new data flows despite parked batch
    expect(cloud.uniqueRecords()).toHaveLength(1);
    store.close();
  });
});

describe('down-sync', () => {
  const cmd = (id: string) => ({
    id,
    company: '',
    date: '20260729',
    voucherType: 'Receipt',
    number: 'R-1',
    narration: 'payment received',
    entries: [
      { ledger: 'Acme Traders', amount: -750 },
      { ledger: 'Bank', amount: 750 },
    ],
  });

  it('imports pending commands once and acks', async () => {
    cloud.pending = [cmd('ext-1')];
    const { store, engine } = makeEngine(join(dir, 'i.db'));
    await engine.tick();
    expect(tally.importedExternalIds).toEqual(['ext-1']);
    expect(cloud.acks).toContainEqual({ id: 'ext-1', status: 'imported' });

    // Redelivery (e.g. lost ack) -> duplicate, not double import.
    cloud.pending = [cmd('ext-1')];
    await engine.tick();
    expect(tally.importedExternalIds).toEqual(['ext-1']);
    expect(cloud.acks).toContainEqual({ id: 'ext-1', status: 'duplicate' });
    store.close();
  });

  it('CHAOS: lost local state -> Tally-side ext-id lookup prevents double import', async () => {
    cloud.pending = [cmd('ext-2')];
    const { store, engine } = makeEngine(join(dir, 'j.db'));
    await engine.tick();
    store.close();

    // Fresh DB = corrupt/lost state scenario from spec §12.
    cloud.pending = [cmd('ext-2')];
    const fresh = makeEngine(join(dir, 'j2.db'));
    await fresh.engine.tick();
    expect(tally.importedExternalIds.filter((x) => x === 'ext-2')).toHaveLength(1);
    expect(cloud.acks.filter((a) => a.id === 'ext-2').map((a) => a.status)).toContain('duplicate');
    fresh.store.close();
  });

  it('Tally rejection is acked failed and does not block other commands', async () => {
    cloud.pending = [cmd('bad-1'), cmd('ok-1')];
    const { store, engine } = makeEngine(join(dir, 'k.db'));

    // Reject only the first import.
    tally.fault = 'import_error';
    const origHandle = tally['handleImport'].bind(tally);
    let first = true;
    (tally as any).handleImport = (body: string, res: any) => {
      if (first) {
        first = false;
        tally.fault = 'import_error';
        const r = origHandle(body, res);
        tally.fault = 'none';
        return r;
      }
      return origHandle(body, res);
    };

    await engine.tick();
    expect(cloud.acks).toContainEqual({ id: 'bad-1', status: 'failed' });
    expect(cloud.acks).toContainEqual({ id: 'ok-1', status: 'imported' });
    store.close();
  });
});

describe('restart durability', () => {
  it('a new engine instance resumes from the persisted cursor', async () => {
    tally.addVoucher();
    const db = join(dir, 'l.db');
    const a = makeEngine(db);
    await a.engine.tick();
    a.store.close();

    tally.addVoucher();
    const b = makeEngine(db);
    await b.engine.tick();
    expect(cloud.uniqueRecords()).toHaveLength(2); // no re-push of voucher 1
    expect(cloud.pushCalls).toBe(2);
    b.store.close();
  });
});

import http from 'node:http';

export type Fault = 'none' | 'timeout' | 'malformed' | 'import_error' | 'http_500' | 'down';

interface SimVoucher {
  GUID: string;
  MASTERID: number;
  ALTERID: number;
  DATE: string;
  VOUCHERTYPENAME: string;
  VOUCHERNUMBER: string;
  PARTYLEDGERNAME: string;
  AMOUNT: number;
  NARRATION: string;
}

/**
 * Speaks enough of the Tally XML gateway dialect for CI: ping, changed-voucher
 * collections (ALTERID filter honored), ext-id lookup, and voucher import.
 * Faults are switchable at runtime so the chaos suite can flip them mid-test.
 */
export class TallySimulator {
  private server: http.Server;
  private alterId = 0;
  private vouchers: SimVoucher[] = [];
  fault: Fault = 'none';
  importedExternalIds: string[] = [];

  constructor() {
    this.server = http.createServer((req, res) => this.handle(req, res));
  }

  listen(port = 0): Promise<number> {
    return new Promise((resolve) =>
      this.server.listen(port, '127.0.0.1', () => resolve((this.server.address() as any).port)),
    );
  }

  close() {
    this.server.close();
  }

  /** Test hook: merchant creates/edits a voucher inside Tally. */
  addVoucher(partial: Partial<SimVoucher> = {}): SimVoucher {
    this.alterId++;
    const v: SimVoucher = {
      GUID: partial.GUID ?? `guid-${this.alterId}`,
      MASTERID: partial.MASTERID ?? this.alterId,
      ALTERID: this.alterId,
      DATE: partial.DATE ?? '20260729',
      VOUCHERTYPENAME: partial.VOUCHERTYPENAME ?? 'Sales',
      VOUCHERNUMBER: partial.VOUCHERNUMBER ?? `V-${this.alterId}`,
      PARTYLEDGERNAME: partial.PARTYLEDGERNAME ?? 'Acme Traders',
      AMOUNT: partial.AMOUNT ?? 1000,
      NARRATION: partial.NARRATION ?? '',
    };
    // Edit = same GUID reappears with a fresh ALTERID.
    this.vouchers = this.vouchers.filter((x) => x.GUID !== v.GUID).concat(v);
    return v;
  }

  private handle(req: http.IncomingMessage, res: http.ServerResponse) {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      if (this.fault === 'down') return req.socket.destroy();
      if (this.fault === 'timeout') return; // never respond; client aborts
      if (this.fault === 'http_500') {
        res.writeHead(500);
        return res.end('boom');
      }
      res.setHeader('Content-Type', 'text/xml');
      if (this.fault === 'malformed') return res.end('<ENVELOPE><BROKEN');

      if (body.includes('<TALLYREQUEST>Import</TALLYREQUEST>')) return this.handleImport(body, res);
      if (body.includes('ExtIdLookup')) return this.handleLookup(body, res);
      if (body.includes('ChangedVouchers')) return this.handleChanged(body, res);
      if (body.includes('ChangedLedgers') || body.includes('ChangedStockItems')) {
        return res.end('<ENVELOPE><BODY><DATA><COLLECTION></COLLECTION></DATA></BODY></ENVELOPE>');
      }
      // ping
      res.end('<ENVELOPE><BODY><DATA><RESULT>Sim Co</RESULT></DATA></BODY></ENVELOPE>');
    });
  }

  private handleChanged(body: string, res: http.ServerResponse) {
    const m = body.match(/\$AlterID\s*&gt;\s*(\d+)/);
    const since = m ? parseInt(m[1], 10) : 0;
    const rows = this.vouchers
      .filter((v) => v.ALTERID > since)
      .map(
        (v) => `<VOUCHER><GUID>${v.GUID}</GUID><MASTERID>${v.MASTERID}</MASTERID><ALTERID>${v.ALTERID}</ALTERID><DATE>${v.DATE}</DATE><VOUCHERTYPENAME>${v.VOUCHERTYPENAME}</VOUCHERTYPENAME><VOUCHERNUMBER>${v.VOUCHERNUMBER}</VOUCHERNUMBER><PARTYLEDGERNAME>${v.PARTYLEDGERNAME}</PARTYLEDGERNAME><AMOUNT>${v.AMOUNT}</AMOUNT><NARRATION>${v.NARRATION}</NARRATION></VOUCHER>`,
      )
      .join('');
    res.end(`<ENVELOPE><BODY><DATA><COLLECTION>${rows}</COLLECTION></DATA></BODY></ENVELOPE>`);
  }

  private handleLookup(body: string, res: http.ServerResponse) {
    const m = body.match(/\[ext:(.+?)\]/);
    const id = m?.[1];
    const found = id && this.importedExternalIds.includes(id);
    res.end(
      `<ENVELOPE><BODY><DATA><COLLECTION>${
        found ? `<VOUCHER><GUID>g</GUID><MASTERID>1</MASTERID><NARRATION>[ext:${id}]</NARRATION></VOUCHER>` : ''
      }</COLLECTION></DATA></BODY></ENVELOPE>`,
    );
  }

  private handleImport(body: string, res: http.ServerResponse) {
    if (this.fault === 'import_error') {
      return res.end(
        '<ENVELOPE><BODY><DATA><IMPORTRESULT><CREATED>0</CREATED><ERRORS>1</ERRORS></IMPORTRESULT></DATA></BODY></ENVELOPE>',
      );
    }
    const m = body.match(/\[ext:(.+?)\]/);
    if (m) this.importedExternalIds.push(m[1]);
    // Imports also bump ALTERID in real Tally — mirror that (echo scenario).
    this.alterId++;
    res.end(
      `<ENVELOPE><BODY><DATA><IMPORTRESULT><CREATED>1</CREATED><ERRORS>0</ERRORS><LASTVCHID>${this.alterId}</LASTVCHID></IMPORTRESULT></DATA></BODY></ENVELOPE>`,
    );
  }
}

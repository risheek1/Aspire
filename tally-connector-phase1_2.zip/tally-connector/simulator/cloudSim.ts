import http from 'node:http';

export type CloudFault = 'none' | 'down' | 'http_500' | 'reject_400';

/**
 * Simulates the Connector Gateway API. Implements the same idempotency the
 * real ingest must have — dedupe on (company, guid, alterId) — so tests can
 * assert "no dupes" through the cloud's eyes, which is the metric that matters.
 */
export class CloudSimulator {
  private server: http.Server;
  fault: CloudFault = 'none';
  received = new Map<string, any>(); // key -> record (idempotent store)
  pushCalls = 0;
  pending: any[] = [];
  acks: { id: string; status: string }[] = [];

  constructor() {
    this.server = http.createServer((req, res) => this.handle(req, res));
  }

  listen(port = 0): Promise<number> {
    return new Promise((resolve) =>
      this.server.listen(port, '127.0.0.1', () => resolve((this.server.address() as any).port)),
    );
  }

  close() {
    this.server.close();
  }

  uniqueRecords(): any[] {
    return [...this.received.values()];
  }

  private handle(req: http.IncomingMessage, res: http.ServerResponse) {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      if (this.fault === 'down') return req.socket.destroy();
      if (this.fault === 'http_500') {
        res.writeHead(500);
        return res.end('{}');
      }
      res.setHeader('Content-Type', 'application/json');
      const url = req.url ?? '';

      if (url.includes('/batch')) {
        if (this.fault === 'reject_400') {
          res.writeHead(400);
          return res.end('{"error":"schema"}');
        }
        this.pushCalls++;
        const parsed = JSON.parse(body);
        for (const r of parsed.records ?? []) {
          this.received.set(`${parsed.company}|${r.guid}|${r.alterId}`, r);
        }
        return res.end('{"ok":true}');
      }
      if (url.endsWith('/pending') && req.method === 'GET') {
        return res.end(JSON.stringify({ items: this.pending }));
      }
      if (url.includes('/pending/') && url.endsWith('/ack')) {
        const id = decodeURIComponent(url.split('/pending/')[1].split('/ack')[0]);
        const { status } = JSON.parse(body || '{}');
        this.acks.push({ id, status });
        // Server-side behavior: stop handing out acknowledged commands.
        if (status === 'imported' || status === 'duplicate') {
          this.pending = this.pending.filter((p) => p.id !== id);
        }
        return res.end('{}');
      }
      if (url.endsWith('/heartbeat')) {
        return res.end('{"config":{}}');
      }
      res.writeHead(404);
      res.end('{}');
    });
  }
}

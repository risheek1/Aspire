import type { Entity } from '../store';
import * as X from './xml';

export class TallyError extends Error {
  constructor(
    public code: 'TALLY_UNREACHABLE' | 'TALLY_TIMEOUT' | 'TALLY_BAD_RESPONSE' | 'TALLY_IMPORT_REJECTED',
    message: string,
  ) {
    super(message);
  }
}

export interface TallyAdapterOptions {
  url: string;
  timeoutMs?: number;
  fetchImpl?: typeof fetch; // injectable for tests
}

export class TallyAdapter {
  private url: string;
  private timeoutMs: number;
  private fetchImpl: typeof fetch;

  constructor(opts: TallyAdapterOptions) {
    this.url = opts.url;
    this.timeoutMs = opts.timeoutMs ?? 30000;
    this.fetchImpl = opts.fetchImpl ?? fetch;
  }

  private async post(xml: string): Promise<string> {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), this.timeoutMs);
    try {
      const res = await this.fetchImpl(this.url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/xml;charset=utf-8' },
        body: xml,
        signal: ctl.signal,
      });
      if (!res.ok) throw new TallyError('TALLY_BAD_RESPONSE', `HTTP ${res.status}`);
      return await res.text();
    } catch (e: any) {
      if (e instanceof TallyError) throw e;
      if (e?.name === 'AbortError') throw new TallyError('TALLY_TIMEOUT', `timeout after ${this.timeoutMs}ms`);
      throw new TallyError('TALLY_UNREACHABLE', e?.message ?? 'connect failed');
    } finally {
      clearTimeout(t);
    }
  }

  async ping(): Promise<boolean> {
    const body = await this.post(X.pingEnvelope());
    return body.includes('<ENVELOPE') || body.includes('RESULT');
  }

  /** One page of changed records: everything with AlterID > since, capped at
   *  pageSize after ascending sort. `hasMore` tells the engine to keep going
   *  within the same tick (bounded by a per-tick page budget). */
  async fetchChanged(
    entity: Entity,
    company: string,
    sinceAlterId: number,
    pageSize: number,
  ): Promise<{ records: X.ChangedRecord[]; hasMore: boolean; maxAlterId: number }> {
    const body = await this.post(X.fetchChangedEnvelope(entity, company, sinceAlterId));
    let records: X.ChangedRecord[];
    try {
      records = X.parseChanged(entity, body);
    } catch (e: any) {
      throw new TallyError('TALLY_BAD_RESPONSE', `parse failed: ${e?.message}`);
    }
    const page = records.slice(0, pageSize);
    return {
      records: page,
      hasMore: records.length > pageSize,
      maxAlterId: page.length ? page[page.length - 1].alterId : sinceAlterId,
    };
  }

  async importVoucher(company: string, cmd: X.VoucherCommand): Promise<X.ImportResult> {
    const body = await this.post(X.importVoucherEnvelope(company, cmd));
    const result = X.parseImportResult(body);
    if (result.errors > 0 || result.created + result.altered === 0) {
      throw new TallyError('TALLY_IMPORT_REJECTED', JSON.stringify(result));
    }
    return result;
  }

  /** Dedupe fallback when local imported_ids state is lost (§12: corrupt state). */
  async existsByExternalId(company: string, externalId: string): Promise<boolean> {
    const body = await this.post(X.findByExternalIdEnvelope(company, externalId));
    return X.parseFound(body);
  }
}

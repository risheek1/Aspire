import { XMLParser } from 'fast-xml-parser';
import type { Entity } from '../store';

const parser = new XMLParser({ ignoreAttributes: false, parseTagValue: true, trimValues: true });

export function escapeXml(s: unknown): string {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function parse(xml: string): any {
  return parser.parse(xml);
}

/** Tally returns an object for one result and an array for many — normalize. */
export function asArray<T>(v: T | T[] | undefined | null): T[] {
  if (v === undefined || v === null) return [];
  return Array.isArray(v) ? v : [v];
}

const companyClause = (company: string) =>
  company ? `<SVCURRENTCOMPANY>${escapeXml(company)}</SVCURRENTCOMPANY>` : '';

export const ENTITY_DEFS: Record<Entity, { tallyType: string; fetch: string; node: string }> = {
  vouchers: {
    tallyType: 'Voucher',
    fetch: 'DATE, VOUCHERTYPENAME, VOUCHERNUMBER, PARTYLEDGERNAME, AMOUNT, NARRATION, GUID, ALTERID, MASTERID',
    node: 'VOUCHER',
  },
  ledgers: {
    tallyType: 'Ledger',
    fetch: 'NAME, PARENT, OPENINGBALANCE, CLOSINGBALANCE, GUID, ALTERID, MASTERID',
    node: 'LEDGER',
  },
  stockitems: {
    tallyType: 'StockItem',
    fetch: 'NAME, PARENT, BASEUNITS, CLOSINGBALANCE, GUID, ALTERID, MASTERID',
    node: 'STOCKITEM',
  },
};

export function pingEnvelope(): string {
  return `<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Function</TYPE><ID>$$CurrentSimpleCompany</ID></HEADER><BODY><DESC></DESC></BODY></ENVELOPE>`;
}

/**
 * Changed-records query: inline TDL collection filtered on AlterID, paged.
 * Paging uses AlterID ordering — the caller passes the last AlterID it has
 * fully processed; we always sort ascending and cap the page in the caller
 * (Tally-side TOP-N support is version-dependent, so we filter client-side).
 */
export function fetchChangedEnvelope(entity: Entity, company: string, sinceAlterId: number): string {
  const d = ENTITY_DEFS[entity];
  const coll = `Changed${d.tallyType}s`;
  return `
<ENVELOPE>
 <HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>${coll}</ID></HEADER>
 <BODY><DESC>
   <STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>${companyClause(company)}</STATICVARIABLES>
   <TDL><TDLMESSAGE>
     <COLLECTION NAME="${coll}" ISMODIFY="No">
       <TYPE>${d.tallyType}</TYPE>
       <FETCH>${d.fetch}</FETCH>
       <FILTER>ChangedFilter</FILTER>
     </COLLECTION>
     <SYSTEM TYPE="Formulae" NAME="ChangedFilter">$AlterID &gt; ${Number(sinceAlterId)}</SYSTEM>
   </TDLMESSAGE></TDL>
 </DESC></BODY>
</ENVELOPE>`;
}

export interface ChangedRecord {
  guid: string;
  masterId: string;
  alterId: number;
  raw: Record<string, unknown>;
}

export function parseChanged(entity: Entity, xml: string): ChangedRecord[] {
  const d = ENTITY_DEFS[entity];
  const doc = parse(xml);
  const rows = asArray<any>(doc?.ENVELOPE?.BODY?.DATA?.COLLECTION?.[d.node]);
  return rows
    .map((r) => ({
      guid: String(r.GUID ?? ''),
      masterId: String(r.MASTERID ?? ''),
      alterId: Number(r.ALTERID ?? 0),
      raw: r as Record<string, unknown>,
    }))
    .sort((a, b) => a.alterId - b.alterId);
}

export interface VoucherCommand {
  id: string; // external id from cloud
  date: string; // YYYYMMDD
  voucherType: string;
  number?: string;
  narration?: string;
  entries: { ledger: string; amount: number }[];
}

export function importVoucherEnvelope(company: string, cmd: VoucherCommand): string {
  const legs = cmd.entries
    .map(
      (e) => `
      <ALLLEDGERENTRIES.LIST>
        <LEDGERNAME>${escapeXml(e.ledger)}</LEDGERNAME>
        <ISDEEMEDPOSITIVE>${e.amount < 0 ? 'Yes' : 'No'}</ISDEEMEDPOSITIVE>
        <AMOUNT>${e.amount}</AMOUNT>
      </ALLLEDGERENTRIES.LIST>`,
    )
    .join('');
  // External id lives in UDF EXTERNALID (v1 also mirrors into narration for
  // visibility to the accountant and pre-UDF Tally builds).
  return `
<ENVELOPE>
 <HEADER><VERSION>1</VERSION><TALLYREQUEST>Import</TALLYREQUEST><TYPE>Data</TYPE><ID>Vouchers</ID></HEADER>
 <BODY><DESC><STATICVARIABLES>${companyClause(company)}</STATICVARIABLES></DESC>
  <DATA><TALLYMESSAGE>
    <VOUCHER VCHTYPE="${escapeXml(cmd.voucherType)}" ACTION="Create">
      <DATE>${escapeXml(cmd.date)}</DATE>
      <VOUCHERTYPENAME>${escapeXml(cmd.voucherType)}</VOUCHERTYPENAME>
      <VOUCHERNUMBER>${escapeXml(cmd.number ?? '')}</VOUCHERNUMBER>
      <NARRATION>${escapeXml(cmd.narration ?? '')} [ext:${escapeXml(cmd.id)}]</NARRATION>
      <UDF:EXTERNALID.LIST DESC="\`ExternalId\`" ISLIST="YES" TYPE="String">
        <UDF:EXTERNALID DESC="\`ExternalId\`">${escapeXml(cmd.id)}</UDF:EXTERNALID>
      </UDF:EXTERNALID.LIST>
      ${legs}
    </VOUCHER>
  </TALLYMESSAGE></DATA>
 </BODY>
</ENVELOPE>`;
}

export interface ImportResult {
  created: number;
  altered: number;
  errors: number;
  lastVchId?: string;
}

export function parseImportResult(xml: string): ImportResult {
  const doc = parse(xml);
  const r = doc?.ENVELOPE?.BODY?.DATA?.IMPORTRESULT ?? {};
  return {
    created: Number(r.CREATED ?? 0),
    altered: Number(r.ALTERED ?? 0),
    errors: Number(r.ERRORS ?? 0),
    lastVchId: r.LASTVCHID !== undefined ? String(r.LASTVCHID) : undefined,
  };
}

/** Query for a voucher carrying our external id UDF (down-sync dedupe fallback
 *  when local imported_ids state was lost). */
export function findByExternalIdEnvelope(company: string, externalId: string): string {
  return `
<ENVELOPE>
 <HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>ExtIdLookup</ID></HEADER>
 <BODY><DESC>
   <STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>${companyClause(company)}</STATICVARIABLES>
   <TDL><TDLMESSAGE>
     <COLLECTION NAME="ExtIdLookup" ISMODIFY="No">
       <TYPE>Voucher</TYPE>
       <FETCH>GUID, MASTERID, NARRATION</FETCH>
       <FILTER>ExtIdFilter</FILTER>
     </COLLECTION>
     <SYSTEM TYPE="Formulae" NAME="ExtIdFilter">$$StringContains:$Narration:"[ext:${escapeXml(externalId)}]"</SYSTEM>
   </TDLMESSAGE></TDL>
 </DESC></BODY>
</ENVELOPE>`;
}

export function parseFound(xml: string): boolean {
  const doc = parse(xml);
  return asArray<any>(doc?.ENVELOPE?.BODY?.DATA?.COLLECTION?.VOUCHER).length > 0;
}

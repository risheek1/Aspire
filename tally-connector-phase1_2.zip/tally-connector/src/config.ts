export interface ConnectorConfig {
  tallyUrl: string;
  companies: string[]; // empty = currently open company
  apiBase: string;
  deviceToken: string;
  pollIntervalMs: number;
  pageSize: number;
  dbPath: string;
  hintPort: number; // localhost listener for the v1.1 TDL push hint; 0 = disabled
  outboxMaxBatches: number;
  logLevel: 'debug' | 'info' | 'warn' | 'error';
}

export function loadConfig(env = process.env): ConnectorConfig {
  return {
    tallyUrl: env.TALLY_URL || 'http://localhost:9000',
    companies: (env.TALLY_COMPANIES || '').split(',').map((s) => s.trim()).filter(Boolean),
    apiBase: env.API_BASE || 'https://connector-gw.example.com',
    deviceToken: env.DEVICE_TOKEN || '',
    pollIntervalMs: int(env.POLL_INTERVAL_MS, 20000),
    pageSize: int(env.PAGE_SIZE, 500),
    dbPath: env.DB_PATH || './connector.db',
    hintPort: int(env.HINT_PORT, 0),
    outboxMaxBatches: int(env.OUTBOX_MAX_BATCHES, 10000),
    logLevel: (env.LOG_LEVEL as ConnectorConfig['logLevel']) || 'info',
  };
}

/** Merge server-pushed config (from heartbeat response) over local config. */
export function applyRemoteConfig(
  base: ConnectorConfig,
  remote: Partial<Pick<ConnectorConfig, 'pollIntervalMs' | 'pageSize' | 'logLevel'>>,
): ConnectorConfig {
  return { ...base, ...remote };
}

function int(v: string | undefined, d: number): number {
  const n = parseInt(v ?? '', 10);
  return Number.isFinite(n) ? n : d;
}

import http from 'node:http';
import { loadConfig, applyRemoteConfig, ConnectorConfig } from './config';
import { Logger } from './logger';
import { Store, Entity } from './store';
import { TallyAdapter } from './tally/adapter';
import { CloudClient } from './cloud/client';
import { SyncEngine } from './sync/engine';

const VERSION = '1.0.0-alpha.1';

export class ConnectorService {
  private cfg: ConnectorConfig;
  private log: Logger;
  private store: Store;
  private engine: SyncEngine;
  private cloud: CloudClient;
  private timer?: NodeJS.Timeout;
  private ticking = false;
  private hintServer?: http.Server;
  private lastReport: import('./sync/engine').TickReport | null = null;
  private lastTickAt: number | null = null;

  constructor(cfg = loadConfig(), log?: Logger) {
    this.cfg = cfg;
    this.log = log ?? new Logger(cfg.logLevel);
    this.store = new Store(cfg.dbPath);
    const tally = new TallyAdapter({ url: cfg.tallyUrl });
    this.cloud = new CloudClient(cfg.apiBase, cfg.deviceToken);
    this.engine = new SyncEngine(tally, this.cloud, this.store, this.log, {
      companies: cfg.companies,
      entities: ['vouchers', 'ledgers', 'stockitems'] as Entity[],
      pageSize: cfg.pageSize,
      maxPagesPerTick: 20,
    });
  }

  start() {
    this.log.info('connector starting', { version: VERSION, tally: this.cfg.tallyUrl });
    this.schedule(0);
    if (this.cfg.hintPort > 0) this.startHintListener();
  }

  private schedule(delayMs: number) {
    this.timer = setTimeout(() => void this.runTick(), delayMs);
  }

  /** Serialized: a hint arriving mid-tick doesn't start a concurrent tick. */
  private async runTick() {
    if (this.ticking) return this.schedule(this.cfg.pollIntervalMs);
    this.ticking = true;
    try {
      const report = await this.engine.tick();
      this.lastReport = report;
      this.lastTickAt = Date.now();
      this.log.debug('tick', report as unknown as Record<string, unknown>);

      const remote = await this.cloud
        .heartbeat({
          version: VERSION,
          tallyUp: report.tallyUp,
          outboxDepth: this.store.outboxDepth(),
          cursors: {},
          errors: report.errors,
        })
        .catch(() => ({}) as Record<string, never>);
      if (Object.keys(remote).length) {
        this.cfg = applyRemoteConfig(this.cfg, remote);
        if (remote.logLevel) this.log.setLevel(remote.logLevel);
      }
    } catch (e: any) {
      this.log.error('tick crashed', { message: e?.message });
    } finally {
      this.ticking = false;
      this.schedule(this.cfg.pollIntervalMs);
    }
  }

  /**
   * v1.1 push-assist (§4.1): Tally's TDL add-on posts here On: Form Accept.
   * FAIL-OPEN CONTRACT: respond <STATUS>1</STATUS> unconditionally and
   * instantly — Tally blocks form acceptance until STATUS=1, so this endpoint
   * must never compute anything before replying. The hint only pulls the next
   * poll forward; the ALTERID cursor remains the source of truth.
   */
  private startHintListener() {
    this.hintServer = http.createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/xml' });
      res.end('<ENVELOPE><STATUS>1</STATUS></ENVELOPE>');
      clearTimeout(this.timer);
      this.schedule(250); // debounce burst of saves into one near-immediate tick
    });
    this.hintServer.listen(this.cfg.hintPort, '127.0.0.1', () =>
      this.log.info('TDL hint listener up', { port: this.cfg.hintPort }),
    );
  }

  /** Consumed by the tray UI over IPC. */
  getStatus() {
    return {
      version: VERSION,
      tallyUp: this.lastReport?.tallyUp ?? false,
      lastTickAt: this.lastTickAt,
      outboxDepth: this.store.outboxDepth(),
      lastReport: this.lastReport,
      logs: this.log.snapshot().slice(-50),
    };
  }

  /** Tray "Sync now" — pulls the next tick forward, serialized like hints. */
  syncNow() {
    clearTimeout(this.timer);
    this.schedule(0);
  }

  async stop() {
    clearTimeout(this.timer);
    this.hintServer?.close();
    this.store.close();
  }
}

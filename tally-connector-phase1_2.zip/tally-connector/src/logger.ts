export type Level = 'debug' | 'info' | 'warn' | 'error';
const ORDER: Record<Level, number> = { debug: 0, info: 1, warn: 2, error: 3 };

export interface LogEntry {
  ts: string;
  level: Level;
  msg: string;
  ctx?: Record<string, unknown>;
}

/**
 * Structured logger with an in-memory ring buffer. The ring is what the tray
 * UI's "send diagnostics" uploads — bounded so we never mirror books to disk.
 */
export class Logger {
  private ring: LogEntry[] = [];
  constructor(
    private minLevel: Level = 'info',
    private ringSize = 2000,
    private sink: (e: LogEntry) => void = (e) =>
      // eslint-disable-next-line no-console
      console.log(`[${e.ts}] ${e.level.toUpperCase()} ${e.msg}${e.ctx ? ' ' + JSON.stringify(e.ctx) : ''}`),
  ) {}

  setLevel(l: Level) {
    this.minLevel = l;
  }

  log(level: Level, msg: string, ctx?: Record<string, unknown>) {
    const entry: LogEntry = { ts: new Date().toISOString(), level, msg, ctx };
    this.ring.push(entry);
    if (this.ring.length > this.ringSize) this.ring.shift();
    if (ORDER[level] >= ORDER[this.minLevel]) this.sink(entry);
  }

  debug(msg: string, ctx?: Record<string, unknown>) { this.log('debug', msg, ctx); }
  info(msg: string, ctx?: Record<string, unknown>) { this.log('info', msg, ctx); }
  warn(msg: string, ctx?: Record<string, unknown>) { this.log('warn', msg, ctx); }
  error(msg: string, ctx?: Record<string, unknown>) { this.log('error', msg, ctx); }

  snapshot(): LogEntry[] {
    return [...this.ring];
  }
}

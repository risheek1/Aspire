import { ConnectorService } from './service';

const svc = new ConnectorService();
svc.start();

process.on('SIGINT', () => void svc.stop().then(() => process.exit(0)));
process.on('SIGTERM', () => void svc.stop().then(() => process.exit(0)));

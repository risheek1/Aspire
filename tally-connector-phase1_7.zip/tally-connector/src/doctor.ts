/**
 * Connectivity doctor: probes every leg of the pipeline independently and
 * says exactly which one is broken. Run with:  node dist/src/doctor.js
 * (or from the installed app dir:  npm run doctor)
 */
import { loadConfig } from './config';
import { Store } from './store';
import { pingEnvelope, fetchChangedEnvelope, parseChanged, ENTITY_DEFS } from './tally/xml';

const cfg = loadConfig();
const ok = (name: string, detail = '') => console.log(`  [PASS] ${name}${detail ? ' — ' + detail : ''}`);
const bad = (name: string, detail: string) => console.log(`  [FAIL] ${name} — ${detail}`);

async function timedFetch(url: string, init: RequestInit, ms = 5000): Promise<Response> {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctl.signal });
  } finally {
    clearTimeout(t);
  }
}

async function main() {
  console.log('tally-connector doctor');
  console.log(`  config: TALLY_URL=${cfg.tallyUrl}  API_BASE=${cfg.apiBase}  DB_PATH=${cfg.dbPath}`);
  console.log(`  device token: ${cfg.deviceToken ? `set (${cfg.deviceToken.length} chars)` : 'NOT SET'}`);
  console.log('');

  // ---- Leg 1: local state (SQLite) ----
  try {
    const s = new Store(cfg.dbPath);
    const depth = s.outboxDepth();
    s.setCursor('__doctor__', 'vouchers', 1);
    s.close();
    ok('local state (SQLite)', `writable, outbox depth=${depth}`);
  } catch (e: any) {
    bad('local state (SQLite)', `${e?.message} — check DB_PATH is writable: ${cfg.dbPath}`);
  }

  // ---- Leg 2: Tally gateway reachable ----
  let tallyOk = false;
  try {
    const res = await timedFetch(cfg.tallyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/xml;charset=utf-8' },
      body: pingEnvelope(),
    });
    const text = await res.text();
    if (res.ok && text.includes('ENVELOPE')) {
      tallyOk = true;
      const m = text.match(/<RESULT[^>]*>([^<]*)<\/RESULT>/);
      ok('Tally gateway', `HTTP ${res.status}, company: ${m?.[1] ?? '(unknown)'}`);
    } else {
      bad('Tally gateway', `HTTP ${res.status}; body starts: ${text.slice(0, 120)}`);
    }
  } catch (e: any) {
    bad(
      'Tally gateway',
      `${e?.name === 'AbortError' ? 'timeout' : e?.cause?.code ?? e?.message}. ` +
        `Is Tally OPEN with a company loaded, and set to act as Server/Both on this port? ` +
        `(TallyPrime: F1 > Settings > Connectivity)`,
    );
  }

  // ---- Leg 3: Tally data query (TDL collection) ----
  if (tallyOk) {
    for (const company of cfg.companies.length ? cfg.companies : ['']) {
      try {
        const res = await timedFetch(cfg.tallyUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/xml;charset=utf-8' },
          body: fetchChangedEnvelope('vouchers', company, 0),
        }, 20000);
        const text = await res.text();
        if (text.includes('LINEERROR') || text.includes('<ERRORS>')) {
          bad(`voucher query${company ? ` (${company})` : ''}`, `Tally returned an error: ${text.slice(0, 300)}`);
        } else {
          const recs = parseChanged('vouchers', text);
          ok(
            `voucher query${company ? ` (${company})` : ''}`,
            `${recs.length} vouchers visible, max AlterID=${recs.length ? recs[recs.length - 1].alterId : 0}`,
          );
          if (recs.length === 0)
            console.log('         (0 can be legit for an empty company — create a test voucher and rerun)');
          else
            console.log('         first raw record: ' + JSON.stringify(recs[0].raw).slice(0, 240));
        }
      } catch (e: any) {
        bad('voucher query', `${e?.message}. Raw response may be malformed — capture it and add as a golden fixture.`);
      }
    }
    // ---- Leg 3b: ledger query (full FETCH, then minimal on failure) ----
    for (const company of cfg.companies.length ? cfg.companies : ['']) {
      for (const fetchList of [undefined, ENTITY_DEFS.ledgers.minimalFetch]) {
        const label = fetchList ? 'ledger query (minimal fields)' : 'ledger query (full fields)';
        try {
          const res = await timedFetch(cfg.tallyUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'text/xml;charset=utf-8' },
            body: fetchChangedEnvelope('ledgers', company, 0, fetchList),
          }, 20000);
          const text = await res.text();
          if (text.includes('LINEERROR') || /<ERRORS>[1-9]/.test(text)) {
            bad(label, `Tally returned an error: ${text.slice(0, 240)}`);
            continue; // try minimal next
          }
          const recs = parseChanged('ledgers', text);
          const invalid = recs.find((r) => !Number.isFinite(r.alterId));
          if (invalid) {
            bad(label, `unparseable ALTERID; raw: ${JSON.stringify(invalid.raw).slice(0, 240)}`);
            continue;
          }
          ok(label, `${recs.length} ledgers, max AlterID=${recs.length ? recs[recs.length - 1].alterId : 0}`);
          if (recs.length) console.log('         first raw record: ' + JSON.stringify(recs[0].raw).slice(0, 240));
          break; // this fetch list works; no need to try minimal
        } catch (e: any) {
          bad(label, `${e?.message}`);
        }
      }
    }
  } else {
    console.log('  [SKIP] voucher/ledger queries — gateway unreachable');
  }

  // ---- Leg 4: cloud gateway ----
  try {
    const res = await timedFetch(`${cfg.apiBase}/v1/connector/heartbeat`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${cfg.deviceToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ version: 'doctor', tallyUp: tallyOk, outboxDepth: 0, cursors: {}, errors: {} }),
    });
    if (res.ok) ok('cloud gateway', `HTTP ${res.status}`);
    else if (res.status === 401 || res.status === 403) bad('cloud gateway', `auth rejected (${res.status}) — check DEVICE_TOKEN`);
    else bad('cloud gateway', `HTTP ${res.status}`);
  } catch (e: any) {
    bad(
      'cloud gateway',
      `${e?.cause?.code ?? e?.message}. If API_BASE is still the placeholder (${cfg.apiBase.includes('example.com') ? 'IT IS' : 'it is not'}), ` +
        `set API_BASE, or run the repo's cloud simulator as a stand-in.`,
    );
  }

  // ---- Leg 5: hint listener port free/ours ----
  if (cfg.hintPort > 0) {
    try {
      const res = await timedFetch(`http://127.0.0.1:${cfg.hintPort}/tally/hint`, { method: 'POST', body: '' }, 2000);
      const text = await res.text();
      if (text.includes('<STATUS>1</STATUS>')) ok('hint listener', `responding fail-open on :${cfg.hintPort}`);
      else bad('hint listener', `something else is on :${cfg.hintPort}: ${text.slice(0, 80)}`);
    } catch {
      console.log(`  [INFO] hint listener not responding on :${cfg.hintPort} (fine if the connector app isn't running)`);
    }
  }

  console.log('\ndone.');
}

main();

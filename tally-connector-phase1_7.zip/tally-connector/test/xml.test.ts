import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import * as X from '../src/tally/xml';

const fx = (name: string) => readFileSync(join(__dirname, '..', 'fixtures', name), 'utf8');

describe('golden: parseChanged', () => {
  it('parses multi-voucher responses and sorts ascending by alterId', () => {
    const recs = X.parseChanged('vouchers', fx('changed_vouchers_multi.xml'));
    expect(recs).toHaveLength(2);
    expect(recs.map((r) => r.alterId)).toEqual([99, 101]); // sorted, not doc order
    expect(recs[1].guid).toBe('g-1');
    expect(recs[1].raw.PARTYLEDGERNAME).toBe('Acme');
  });

  it('handles the single-element case (Tally returns object, not array)', () => {
    const recs = X.parseChanged('vouchers', fx('changed_vouchers_single.xml'));
    expect(recs).toHaveLength(1);
    expect(recs[0].guid).toBe('g-solo');
    expect(recs[0].alterId).toBe(42);
  });

  it('returns empty for empty collections', () => {
    const recs = X.parseChanged(
      'vouchers',
      '<ENVELOPE><BODY><DATA><COLLECTION></COLLECTION></DATA></BODY></ENVELOPE>',
    );
    expect(recs).toEqual([]);
  });
});

describe('golden: import results', () => {
  it('parses success with LASTVCHID', () => {
    const r = X.parseImportResult(fx('import_success.xml'));
    expect(r).toEqual({ created: 1, altered: 0, errors: 0, lastVchId: '3021' });
  });
  it('parses rejection', () => {
    const r = X.parseImportResult(fx('import_rejected.xml'));
    expect(r.errors).toBe(1);
    expect(r.created).toBe(0);
  });
});

describe('envelope builders', () => {
  it('embeds the AlterID filter and entity fetch list', () => {
    const env = X.fetchChangedEnvelope('vouchers', 'My Co', 12345);
    expect(env).toContain('$AlterID &gt; 12345');
    expect(env).toContain('<SVCURRENTCOMPANY>My Co</SVCURRENTCOMPANY>');
    expect(env).toContain('ALTERID, MASTERID');
  });

  it('escapes XML-hostile input everywhere user data lands', () => {
    const env = X.importVoucherEnvelope('A & B "Co"', {
      id: 'x</NARRATION><HACK>',
      date: '20260729',
      voucherType: 'Sales',
      narration: '<script>',
      entries: [{ ledger: 'L & M', amount: 10 }],
    });
    expect(env).not.toContain('<HACK>');
    expect(env).toContain('&lt;script&gt;');
    expect(env).toContain('L &amp; M');
    expect(env).toContain('A &amp; B &quot;Co&quot;');
  });

  it('sets debit/credit convention from amount sign', () => {
    const env = X.importVoucherEnvelope('', {
      id: '1',
      date: '20260729',
      voucherType: 'Receipt',
      entries: [
        { ledger: 'Party', amount: -500 },
        { ledger: 'Bank', amount: 500 },
      ],
    });
    expect(env).toContain('<ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>');
    expect(env).toContain('<ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>');
  });
});

describe('golden: real-Tally field shapes (attributed elements)', () => {
  // Regression for prod crash: NOT NULL constraint failed: cursors.alter_id.
  // Attributed elements parse as objects; values may carry spaces/commas.
  it('coerces object-shaped ALTERID/GUID with spaces and comma grouping', () => {
    const recs = X.parseChanged('vouchers', fx('changed_vouchers_attributed.xml'));
    expect(recs).toHaveLength(2);
    expect(recs.map((r) => r.alterId)).toEqual([1199, 1204]);
    expect(recs[1].guid).toBe('g-attr-1');
    expect(recs[1].masterId).toBe('501');
  });

  it('toInt/toText handle every observed shape', () => {
    expect(X.toInt({ '#text': ' 1,204', '@_TYPE': 'Number' })).toBe(1204);
    expect(X.toInt(' 42 ')).toBe(42);
    expect(X.toInt(7)).toBe(7);
    expect(Number.isNaN(X.toInt(undefined))).toBe(true);
    expect(Number.isNaN(X.toInt({ '@_TYPE': 'Number' }))).toBe(true);
    expect(X.toText({ '#text': 'abc' })).toBe('abc');
  });
});

describe('golden: company info', () => {
  it('parses attributed company fields', () => {
    const xml = '<ENVELOPE><BODY><DATA><COLLECTION><COMPANY><NAME TYPE="String"> Acme Industries </NAME><GUID>abc-123</GUID><STARTINGFROM TYPE="Date">20250401</STARTINGFROM><BOOKSFROM>20250401</BOOKSFROM></COMPANY></COLLECTION></DATA></BODY></ENVELOPE>';
    const cos = X.parseCompanies(xml);
    expect(cos).toEqual([{ name: 'Acme Industries', guid: 'abc-123', startingFrom: '20250401', booksFrom: '20250401' }]);
  });
  it('handles zero companies', () => {
    expect(X.parseCompanies('<ENVELOPE><BODY><DATA><COLLECTION></COLLECTION></DATA></BODY></ENVELOPE>')).toEqual([]);
  });
});

describe('regression: real-Tally empty attributed fields (from doctor capture)', () => {
  it('flattens {"@_TYPE":"String"} (empty NARRATION) to empty string', () => {
    // exact shape observed on real TallyPrime via npm run doctor
    const xml = '<ENVELOPE><BODY><DATA><COLLECTION><VOUCHER><GUID>573a4a44-x-00000001</GUID><ALTERID>33</ALTERID><NARRATION TYPE="String"></NARRATION><VOUCHERTYPENAME>RazorpayX Purchase</VOUCHERTYPENAME><PARTYLEDGERNAME>Sushma</PARTYLEDGERNAME><VOUCHERNUMBER>1</VOUCHERNUMBER></VOUCHER></COLLECTION></DATA></BODY></ENVELOPE>';
    const recs = X.parseChanged('vouchers', xml);
    expect(recs[0].raw.NARRATION).toBe('');
    expect(recs[0].raw.VOUCHERTYPENAME).toBe('RazorpayX Purchase');
    expect(recs[0].alterId).toBe(33);
  });
});

describe('fetch degrade fallback', () => {
  it('adapter falls back to minimal FETCH when the full list yields unparseable data', async () => {
    const { TallyAdapter } = await import('../src/tally/adapter');
    const calls: string[] = [];
    const fakeFetch = (async (_url: any, init: any) => {
      const body = String(init.body);
      calls.push(body.includes('PARTYGSTIN') ? 'full' : 'minimal');
      const payload = body.includes('PARTYGSTIN')
        // full fetch: pathological response with unparseable ALTERID
        ? '<ENVELOPE><BODY><DATA><COLLECTION><LEDGER><GUID>g</GUID><ALTERID>##ERR##</ALTERID></LEDGER></COLLECTION></DATA></BODY></ENVELOPE>'
        : '<ENVELOPE><BODY><DATA><COLLECTION><LEDGER><NAME>Acme</NAME><GUID>g</GUID><ALTERID>7</ALTERID></LEDGER></COLLECTION></DATA></BODY></ENVELOPE>';
      return new Response(payload, { status: 200, headers: { 'Content-Type': 'text/xml' } });
    }) as typeof fetch;

    const adapter = new TallyAdapter({ url: 'http://tally.test', fetchImpl: fakeFetch });
    const warns: string[] = [];
    const page = await adapter.fetchChanged('ledgers', '', 0, 10, (m) => warns.push(m));
    expect(calls).toEqual(['full', 'minimal']);
    expect(page.degraded).toBe(true);
    expect(page.records[0].alterId).toBe(7);
    expect(warns[0]).toContain('retrying with minimal fields');
  });
});
